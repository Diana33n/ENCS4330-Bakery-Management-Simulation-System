#ifndef MESSAGE_H
#define MESSAGE_H
#define MSG_TYPE_SELLER_RESPONSE_BASE 10000

#include <sys/types.h>

#define MAX_ITEM_NAME_LEN 50
#define MAX_MSG_SIZE 256
#define MSG_TYPE_CUSTOMER_REQUEST 1
#define MSG_TYPE_SELLER_RESPONSE 2
#define MSG_TYPE_COMPLAINT 3
#define MSG_QUEUE_KEY 0x12345
#define MAX_ITEMS_PER_ORDER 3
#define MSG_TYPE_FRUSTRATION_UPDATE 4     // For customers reporting they're leaving
#define MSG_TYPE_FRUSTRATION_EXIT 8     // For customers reporting they're leaving
#define MSG_TYPE_REQUEST_CANCELLATION 9
#define MSG_TYPE_CUSTOMER_COMPLAINT 5
#define MSG_TYPE_REFUND_ACK 6

// Add these to message.h
#define MSG_TYPE_CUSTOMER_ENTERED   1001
#define MSG_TYPE_CUSTOMER_LEFT      1002
#define MSG_TYPE_CUSTOMER_STATE     1003



// In message.h, add these near the top (after the includes but before other definitions)
// Customer state definitions
#define CUSTOMER_ENTERING 0
#define CUSTOMER_WAITING 1
#define CUSTOMER_BEING_SERVED 2
#define CUSTOMER_HAPPY_EXIT 3
#define CUSTOMER_FRUSTRATED_EXIT 4
#define CUSTOMER_REFUND_PROCESSING 5
// In message.h, add this to the state definitions
#define CUSTOMER_ORDERING 6  // New state for ordering phase

typedef struct {
    long mtype;
    pid_t customer_pid;

    int state;  // 0=entering, 1=waiting, 2=being served, 3=happy exit, 4=frustrated exit
    char items[256]; // Items being purchased
    int timeout; // Timeout value
} CustomerStateMessage;


// In message.h, add this near other message types
#define MSG_TYPE_SELLER_STATE 1004  // New message type for sellers

typedef struct {
    long mtype;  // MSG_TYPE_SELLER_STATE
    pid_t seller_pid;
    int state;    // 0=idle, 1=serving, 2=processing payment, 3=processing refund
    char status[128];
} SellerStateMessage;


typedef struct {
    long mtype;
    pid_t customer_pid;
    time_t request_timestamp;
} RequestCancellationMessage;

typedef enum {
    BREAD,
    SANDWICH,
    CAKE,
    SWEET,
    PATISSERIE
} ItemType;

typedef enum {
    WHITE,
    BROWN
} BreadType;

typedef enum {
    CHEESE,
    SALAMI,
    BOTH
} SandwichType;

typedef enum {
    CHOCOLATE,
    VANILLA,
    STRAWBERRY,
    BLUEBERRY
} CakeFlavor;

typedef enum {
    DONUT,
    CROISSANT,
    COOKIE,
    CUPCAKE
} SweetFlavor;

typedef enum {
    SWEET_PAT,
    SAVORY_PAT
} PatisserieType;

typedef struct {
    long mtype;
    pid_t customer_pid;
    int num_items;
    time_t timestamp;
    int timeout;
    struct {
        ItemType item_type;
        union {
            BreadType bread_type;
            struct {
                SandwichType sandwich_type;
                BreadType bread_type;
            } sandwich;
            CakeFlavor cake_flavor;
            SweetFlavor sweet_flavor;
            PatisserieType patisserie_type;
        } details;
        int quantity;
    } items[MAX_ITEMS_PER_ORDER];
} CustomerRequest;

typedef struct {
    long mtype;
    int success;
    int total_price;
    int item_success[MAX_ITEMS_PER_ORDER];
    int remaining_stocks[MAX_ITEMS_PER_ORDER];
} SellerResponse;

typedef struct {
    long mtype; // MSG_TYPE_COMPLAINT
    int severity; // 1-3 scale
} ComplaintMessage;

typedef struct {
    long mtype;
    int frustrated_count; // Number of customers who left due to this complaint
} FrustrationUpdateMessage;
typedef struct {
    long mtype;
    pid_t customer_pid;
    int total_price;  // Amount to refund
} CustomerComplaintMessage;


typedef struct {
    long mtype; // customer pid
    int amount;
} RefundAckMessage;
#endif // MESSAGE_H