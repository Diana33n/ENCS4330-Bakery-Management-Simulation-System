#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/msg.h>
#include <signal.h>
#include "pantry.h"
#include "message.h"
#define GREEN   "\x1B[32m"
#include <string.h>


#define YELLOW  "\x1B[33m"
#define RESET   "\x1B[0m"
#define RED     "\x1B[31m"

volatile sig_atomic_t stop = 0;
static int msgid;
static Inventory *inv = NULL;  // Add this with other global variables at the top

void handle_sigterm(int sig) {

    stop = 1;

}

const char* bread_type_to_str(BreadType type) {
    return type == WHITE ? "White" : "Brown";
}

const char* sandwich_type_to_str(SandwichType type) {
    switch(type) {
        case CHEESE: return "Cheese";
        case SALAMI: return "Salami";
        case BOTH: return "Cheese & Salami";
        default: return "Unknown";
    }
}

const char* cake_flavor_to_str(CakeFlavor flavor) {
    switch(flavor) {
        case CHOCOLATE: return "Chocolate";
        case VANILLA: return "Vanilla";
        case STRAWBERRY: return "Strawberry";
        case BLUEBERRY: return "Blueberry";
        default: return "Unknown";
    }
}

const char* sweet_flavor_to_str(SweetFlavor flavor) {
    switch(flavor) {
        case DONUT: return "Donut";
        case CROISSANT: return "Croissant";
        case COOKIE: return "Cookie";
        case CUPCAKE: return "Cupcake";
        default: return "Unknown";
    }
}

const char* patisserie_type_to_str(PatisserieType type) {
    return type == SWEET_PAT ? "Sweet" : "Savory";
}

int calculate_price(ItemType item_type, const Inventory *inv) {
    switch(item_type) {
        case BREAD: return inv->bread_price;
        case SANDWICH: return inv->sandwich_price;
        case CAKE: return inv->cake_price;
        case SWEET: return inv->sweet_price;
        case PATISSERIE: return inv->patisserie_price;
        default: return 0;
    }
}

void print_stock_info(const Inventory *inv) {
    printf(YELLOW "[Seller %d] Current Stock:\n" RESET, getpid());
    printf(YELLOW "  Bread - White: %d, Brown: %d\n" RESET,
           inv->bread_white_ready, inv->bread_brown_ready);
    printf(YELLOW "  Sandwiches:\n" RESET);
    printf(YELLOW "    Cheese - White: %d, Brown: %d\n" RESET,
           inv->sandwich_cheese_white_count, inv->sandwich_cheese_brown_count);
    printf(YELLOW "    Salami - White: %d, Brown: %d\n" RESET,
           inv->sandwich_salami_white_count, inv->sandwich_salami_brown_count);
    printf(YELLOW "    Both - White: %d, Brown: %d\n" RESET,
           inv->sandwich_both_white_count, inv->sandwich_both_brown_count);
    printf(YELLOW "  Cakes - Chocolate: %d, Vanilla: %d, Strawberry: %d, Blueberry: %d\n" RESET,
           inv->total_chocolate_cakes_ready_to_sell, inv->total_vanilla_cakes_ready_to_sell,
           inv->total_strawberry_cakes_ready_to_sell, inv->total_blueburry_cakes_ready_to_sell);
    printf(YELLOW "  Sweets - Donut: %d, Croissant: %d, Cookie: %d, Cupcake: %d\n" RESET,
           inv->total_donut_sweets_ready_to_sell, inv->total_croissant_sweets_ready_to_sell,
           inv->total_cookie_sweets_ready_to_sell, inv->total_cupcake_sweets_ready_to_sell);
    printf(YELLOW "  Patisseries - Sweet: %d, Savory: %d\n" RESET,
           inv->total_sweet_patisseries_ready_to_sell, inv->total_savory_patisseries_ready_to_sell);
}

int process_request(CustomerRequest *req, Inventory *inv, int *remaining_stocks, int *item_success, int *total_price) {
    int any_success = 0;
    int overall_success = 1;
    *total_price = 0;

    for (int i = 0; i < req->num_items; i++) {
        item_success[i] = 0;
        int *stock = NULL;
        sem_t *item_mutex = NULL;

        // Determine which mutex and stock to use
        switch(req->items[i].item_type) {
            case BREAD:
                item_mutex = &inv->sem_bread_types;
                stock = (req->items[i].details.bread_type == WHITE)
                      ? &inv->bread_white_ready : &inv->bread_brown_ready;
                break;

            case SANDWICH:
                item_mutex = &inv->sem_sandwich;
                switch(req->items[i].details.sandwich.sandwich_type) {
                    case CHEESE:
                        stock = (req->items[i].details.sandwich.bread_type == WHITE)
                              ? &inv->sandwich_cheese_white_count
                              : &inv->sandwich_cheese_brown_count;
                        break;
                    case SALAMI:
                        stock = (req->items[i].details.sandwich.bread_type == WHITE)
                              ? &inv->sandwich_salami_white_count
                              : &inv->sandwich_salami_brown_count;
                        break;
                    case BOTH:
                        stock = (req->items[i].details.sandwich.bread_type == WHITE)
                              ? &inv->sandwich_both_white_count
                              : &inv->sandwich_both_brown_count;
                        break;
                }
                break;

            case CAKE:
                item_mutex = &inv->sem_total_cake_count;
                switch(req->items[i].details.cake_flavor) {
                    case CHOCOLATE: stock = &inv->total_chocolate_cakes_ready_to_sell; break;
                    case VANILLA:   stock = &inv->total_vanilla_cakes_ready_to_sell;   break;
                    case STRAWBERRY:stock = &inv->total_strawberry_cakes_ready_to_sell;break;
                    case BLUEBERRY: stock = &inv->total_blueburry_cakes_ready_to_sell; break;
                }
                break;

            case SWEET:
                item_mutex = &inv->sem_total_sweet_count;
                switch(req->items[i].details.sweet_flavor) {
                    case DONUT:    stock = &inv->total_donut_sweets_ready_to_sell;    break;
                    case CROISSANT:stock = &inv->total_croissant_sweets_ready_to_sell; break;
                    case COOKIE:   stock = &inv->total_cookie_sweets_ready_to_sell;    break;
                    case CUPCAKE:  stock = &inv->total_cupcake_sweets_ready_to_sell;  break;
                }
                break;

            case PATISSERIE:
                item_mutex = (req->items[i].details.patisserie_type == SWEET_PAT)
                          ? &inv->sem_total_sweet_patisserie
                          : &inv->sem_total_savory_patisserie;
                stock = (req->items[i].details.patisserie_type == SWEET_PAT)
                      ? &inv->total_sweet_patisseries_ready_to_sell
                      : &inv->total_savory_patisseries_ready_to_sell;
                break;
        }

        if (stock && item_mutex) {
            sem_wait(item_mutex);

            remaining_stocks[i] = *stock;
            if (*stock >= req->items[i].quantity) {
                *stock -= req->items[i].quantity;
                *total_price += req->items[i].quantity * calculate_price(req->items[i].item_type, inv);
                item_success[i] = 1;
                any_success = 1;
                remaining_stocks[i] = *stock;
            } else {
                overall_success = 0;
            }

            sem_post(item_mutex);
        } else {
            overall_success = 0;
        }
    }

    if (any_success) {
        sem_wait(&inv->stats_mutex);
        inv->profit += *total_price;
        sem_post(&inv->stats_mutex);
    }

    return overall_success;
}
void send_customer_state(int state, const char* items, int timeout) {
    CustomerStateMessage msg;
    msg.mtype = MSG_TYPE_CUSTOMER_STATE;
    msg.customer_pid = getpid();
    msg.state = state;
    strncpy(msg.items, items, sizeof(msg.items)-1);
    msg.timeout = timeout;

    if (msgsnd(msgid, &msg, sizeof(CustomerStateMessage) - sizeof(long), 0) ){
        perror("msgsnd failed for customer state");
    }
}
void print_request_details(const CustomerRequest *req) {
    printf(YELLOW "[Seller %d] Processing Order (%d items):\n" RESET, getpid(), req->num_items);
    printf(YELLOW "  Customer PID: %d\n" RESET, req->customer_pid);
    //printf(YELLOW "  Timeout: %d seconds\n" RESET, req->timeout);

    for (int i = 0; i < req->num_items; i++) {
        printf(YELLOW "  Item %d:\n" RESET, i+1);
        printf(YELLOW "    Type: " RESET);

        switch(req->items[i].item_type) {
            case BREAD:
                printf(YELLOW "Bread (%s)\n" RESET, bread_type_to_str(req->items[i].details.bread_type));
                break;
            case SANDWICH:
                printf(YELLOW "Sandwich - Type: %s, Bread: %s\n" RESET,
                       sandwich_type_to_str(req->items[i].details.sandwich.sandwich_type),
                       bread_type_to_str(req->items[i].details.sandwich.bread_type));
                break;
            case CAKE:
                printf(YELLOW "Cake (%s)\n" RESET, cake_flavor_to_str(req->items[i].details.cake_flavor));
                break;
            case SWEET:
                printf(YELLOW "Sweet (%s)\n" RESET, sweet_flavor_to_str(req->items[i].details.sweet_flavor));
                break;
            case PATISSERIE:
                printf(YELLOW "Patisserie (%s)\n" RESET, patisserie_type_to_str(req->items[i].details.patisserie_type));
                break;
        }
        printf(YELLOW "    Quantity: %d\n" RESET, req->items[i].quantity);
    }
}
// Add this function to seller.c
void send_seller_state(int state, const char* status) {
    SellerStateMessage msg;
    msg.mtype = MSG_TYPE_SELLER_STATE;
    msg.seller_pid = getpid();
    msg.state = state;
    strncpy(msg.status, status, sizeof(msg.status)-1);

    if (msgsnd(msgid, &msg, sizeof(SellerStateMessage) - sizeof(long), 0)) {
        perror("msgsnd failed for seller state");
    }
}

int main() {
    signal(SIGTERM, handle_sigterm);
    srand(getpid());

    msgid = msgget(MSG_QUEUE_KEY, IPC_CREAT | 0666);
    inv = init_pantry(0);
    send_seller_state(0, "Ready to serve"); // Initial idle state

    printf(YELLOW "[Seller %d] Ready to serve customers!\n" RESET, getpid());
    printf(YELLOW "[Seller %d] Initial profit: %d\n" RESET, getpid(), inv->profit);

    CustomerRequest req;
    SellerResponse resp;

    while (!stop) {
        // 1. First check for customer complaints (highest priority)
        CustomerComplaintMessage cust_complaint;
        if (msgrcv(msgid, &cust_complaint, sizeof(CustomerComplaintMessage) - sizeof(long),
             MSG_TYPE_CUSTOMER_COMPLAINT, IPC_NOWAIT) != -1) {
            send_seller_state(3, "Processing refund");
            sleep(1);

            printf(YELLOW "\n[Seller %d] REFUND PROCESSING:\n" RESET, getpid());
            printf(YELLOW "  Customer PID: %d\n" RESET, cust_complaint.customer_pid);
            printf(YELLOW "  Refund amount: %d\n" RESET, cust_complaint.total_price);

            sem_wait(&inv->stats_mutex);
            printf(YELLOW "  Previous profit: %d\n" RESET, inv->profit);
            inv->profit -= cust_complaint.total_price;
            inv->complaints++;
            printf(YELLOW "  New profit after refund: %d\n" RESET, inv->profit);
            printf(YELLOW "  Total complaints: %d\n\n" RESET, inv->complaints);
            sem_post(&inv->stats_mutex);

            // Send refund acknowledgment
            RefundAckMessage ack = {
                .mtype = cust_complaint.customer_pid,
                .amount = cust_complaint.total_price
            };
            msgsnd(msgid, &ack, sizeof(RefundAckMessage) - sizeof(long), 0);
            printf(YELLOW "[Seller %d] Sent refund acknowledgment to customer %d\n\n" RESET,
                   getpid(), cust_complaint.customer_pid);

            send_seller_state(0, "Ready to serve"); // Back to idle
            continue;
        }

        // 2. Check for request cancellations
        RequestCancellationMessage cancel_msg;
        if (msgrcv(msgid, &cancel_msg, sizeof(RequestCancellationMessage) - sizeof(long),
             MSG_TYPE_REQUEST_CANCELLATION, IPC_NOWAIT) != -1) {
            printf(YELLOW "[Seller %d] REQUEST CANCELLED:\n" RESET, getpid());
            printf(YELLOW "  Customer PID: %d\n" RESET, cancel_msg.customer_pid);

            sem_wait(&inv->stats_mutex);
            inv->frustrated_waiting++;
            printf(RED "  Added to timeout frustrations (total: %d)\n\n" RESET, inv->frustrated_waiting);
            sem_post(&inv->stats_mutex);
            send_customer_state(CUSTOMER_FRUSTRATED_EXIT, "Timed out", req.timeout);

            continue;
        }

        // 3. Handle regular requests
        if (msgrcv(msgid, &req, sizeof(CustomerRequest) - sizeof(long), MSG_TYPE_CUSTOMER_REQUEST, 0) == -1) {
            if (stop) break;
            perror("msgrcv failed");
            continue;
        }

        // Double-check if request was cancelled while in queue
        if (msgrcv(msgid, &cancel_msg, sizeof(RequestCancellationMessage) - sizeof(long),
             MSG_TYPE_REQUEST_CANCELLATION, IPC_NOWAIT) != -1) {
            if (cancel_msg.customer_pid == req.customer_pid) {
                printf(YELLOW "[Seller %d] SKIPPING CANCELLED REQUEST FROM PID %d\n" RESET,
                       getpid(), req.customer_pid);

                sem_wait(&inv->stats_mutex);
                inv->frustrated_waiting++;
                sem_post(&inv->stats_mutex);
                send_customer_state(CUSTOMER_FRUSTRATED_EXIT, "Timed out", req.timeout);

                continue;
            }
            // If not for this request, put message back
            msgsnd(msgid, &cancel_msg, sizeof(RequestCancellationMessage) - sizeof(long), 0);
        }

        send_seller_state(1, "Processing order");
        sleep(1);

        // Process order (with all semaphore locks)
        sem_wait(&inv->sem_bread_types);
        sem_wait(&inv->sem_sandwich);
        sem_wait(&inv->sem_total_cake_count);
        sem_wait(&inv->sem_total_sweet_count);
        sem_wait(&inv->sem_total_sweet_patisserie);
        sem_wait(&inv->sem_total_savory_patisserie);

        print_request_details(&req);
        print_stock_info(inv);

        sem_post(&inv->sem_total_savory_patisserie);
        sem_post(&inv->sem_total_sweet_patisserie);
        sem_post(&inv->sem_total_sweet_count);
        sem_post(&inv->sem_total_cake_count);
        sem_post(&inv->sem_sandwich);
        sem_post(&inv->sem_bread_types);

        int remaining_stocks[MAX_ITEMS_PER_ORDER] = {0};
        int item_success[MAX_ITEMS_PER_ORDER] = {0};
        int total_price = 0;
        int overall_success = process_request(&req, inv, remaining_stocks, item_success, &total_price);

        send_seller_state(2, "Processing payment");
        sleep(1);

        // Handle any frustration updates while processing
        FrustrationUpdateMessage frust_msg;
        while (msgrcv(msgid, &frust_msg, sizeof(FrustrationUpdateMessage) - sizeof(long),
                 MSG_TYPE_FRUSTRATION_UPDATE, IPC_NOWAIT) != -1) {
            sem_wait(&inv->stats_mutex);
            inv->frustrated_customers += frust_msg.frustrated_count;
            printf(RED "\n[Seller %d] FRUSTRATION UPDATE:\n" RESET, getpid());
            printf(RED "  Customers left due to complaints: %d\n" RESET, frust_msg.frustrated_count);
            printf(RED "  Total complaint frustrations: %d\n\n" RESET, inv->frustrated_customers);
            sem_post(&inv->stats_mutex);
        }

        // Prepare and send response
        resp.mtype = req.customer_pid;
        resp.success = overall_success;
        resp.total_price = total_price;
        for (int i = 0; i < req.num_items; i++) {
            resp.item_success[i] = item_success[i];
            resp.remaining_stocks[i] = remaining_stocks[i];
        }

        if (msgsnd(msgid, &resp, sizeof(SellerResponse) - sizeof(long), 0) == -1) {
            perror("msgsnd failed");
        }

        // Print transaction result
        printf(YELLOW "\n[Seller %d] TRANSACTION SUMMARY:\n" RESET, getpid());
        printf(YELLOW "  Customer PID: %d\n" RESET, req.customer_pid);
        printf(YELLOW "  Status: %s\n" RESET, overall_success ? "FULL SUCCESS" : "PARTIAL/FAILED");
        printf(YELLOW "  Total price: %d\n" RESET, total_price);

        sem_wait(&inv->stats_mutex);
        printf(YELLOW "  Current profit: %d\n" RESET, inv->profit);
        printf(YELLOW "  Total complaints: %d\n" RESET, inv->complaints);
        printf(YELLOW "  Frustrated customers: %d (timeouts) + %d (complaints) = %d\n\n" RESET,
               inv->frustrated_waiting, inv->frustrated_customers,
               inv->frustrated_waiting + inv->frustrated_customers);
        sem_post(&inv->stats_mutex);

        for (int i = 0; i < req.num_items; i++) {
            if (item_success[i]) {
                printf(GREEN "  SOLD: Item %d (%d units), Remaining: %d\n" RESET,
                       i+1, req.items[i].quantity, remaining_stocks[i]);
            } else {
                printf(RED "  FAILED: Item %d (Requested: %d, Available: %d)\n" RESET,
                       i+1, req.items[i].quantity, remaining_stocks[i]);
            }
        }

        send_seller_state(0, "Ready to serve");
        printf("\n");
    }

    printf(YELLOW "\n[Seller %d] FINAL REPORT:\n" RESET, getpid());
    printf(YELLOW "  Total profit: %d\n" RESET, inv->profit);
    printf(YELLOW "  Total complaints: %d\n" RESET, inv->complaints);
    printf(YELLOW "  Frustrated customers:\n" RESET);
    printf(YELLOW "    Due to timeouts: %d\n" RESET, inv->frustrated_waiting);
    printf(YELLOW "    Due to complaints: %d\n" RESET, inv->frustrated_customers);
    printf(YELLOW "    Total: %d\n" RESET, inv->frustrated_waiting + inv->frustrated_customers);
    printf(YELLOW "[Seller %d] Shutting down...\n\n" RESET, getpid());

    return 0;
}