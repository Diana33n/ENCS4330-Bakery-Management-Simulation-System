#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "pantry.h"

#define SHM_KEY 0x1234
#include <sys/types.h>
#include <unistd.h>

pid_t chef_pids[MAX_CHEFS];  // ✅ Definition of the global array

static int shm_id;
static Inventory *inv;

Inventory *init_pantry(int create) {
    printf("Shared memory size = %lu bytes\n", sizeof(Inventory));

    if (create) {
        shm_id = shmget(SHM_KEY, sizeof(Inventory), IPC_CREAT | 0666);
        if (shm_id < 0) {
            perror("Failed to create shared memory");
            exit(1);
        }
    } else {
        shm_id = shmget(SHM_KEY, sizeof(Inventory), 0666);
        if (shm_id < 0) {
            perror("Failed to access shared memory");
            exit(1);
        }
    }

    inv = (Inventory *)shmat(shm_id, NULL, 0);
    if (inv == (Inventory *)(-1)) {
        perror("Failed to attach shared memory");
        exit(1);
    }

    if (create) {
        sem_init(&inv->mutex, 1, 1); //  Here INSIDE the function
        sem_init(&inv->stats_mutex, 1, 1); // Separate mutex for statistics
        sem_init(&inv->sem_base_ingredients, 1, 1);
        sem_init(&inv->sem_cheese_salami, 1, 1);
        sem_init(&inv->sem_salt, 1, 1);
        sem_init(&inv->sem_paste, 1, 1);

        sem_init(&inv->sem_cake_flavors, 1, 1);
        sem_init(&inv->sem_total_cake_count, 1, 1);

        sem_init(&inv->sem_sweet_flavors, 1, 1);
        sem_init(&inv->sem_total_sweet_count, 1, 1);

        sem_init(&inv->sem_sweet_patisserie, 1, 1);
        sem_init(&inv->sem_total_sweet_patisserie, 1, 1);

        sem_init(&inv->sem_savory_patisserie, 1, 1);
        sem_init(&inv->sem_total_savory_patisserie, 1, 1);
        sem_init(&inv->sem_sandwich, 1, 1);

        sem_init(&inv->sem_bread_types, 1, 1);

        sem_init(&inv->sem_manager, 1, 1);

        for (int i = 0; i < OVEN_COUNT; i++) {
            inv->ovens[i] = 0;
            inv->oven_in_use_by[i] = -1;

            sem_init(&inv->oven_mutex[i], 1, 1);  // 1 = shared between processes
        }

        for(int i=0;i<MAX_BAKERS;i++){
            inv->baker_is_delivering[i] = 0;
            inv->baker_delivery_timer[i] = 0;
        }
        for(int i=0;i<MAX_sandwich_chefs;i++){
            inv->sandwich_chef_is_delivering[i] = 0;
            inv->sandwich_chef_timer[i] = 0;
        }

        for (int i = 0; i < MAX_CHEFS; i++) {
            inv->swaped_chef[i] = 0;
        }
        inv->num_supply_chain = 0; 

        
    }

    return inv;
}


void load_initial_stock(Inventory *inv, const Config *cfg) {
    inv->num_supply_chain = cfg->num_supply_chain;
    inv->wheat = cfg->wheat;
    inv->yeast = cfg->yeast;
    inv->butter = cfg->butter;
    inv->milk = cfg->milk;
    inv->sugar = cfg->sugar;
    inv->salt = cfg->salt;
    inv->sweet_items = cfg->sweet_items;
    inv->cheese = cfg->cheese;
    inv->salami = cfg->salami;
    inv->sandwich_type_cheese = cfg->sandwich_type_cheese;
    inv->sandwich_type_salami = cfg->sandwich_type_salami;
    inv->sandwich_type_both = cfg->sandwich_type_both;
    inv->cake_flavor_Chocolate = cfg->cake_flavor_Chocolate;
    inv->cake_flavor_Vanilla = cfg->cake_flavor_Vanilla;
    inv->cake_flavor_Strawberry = cfg->cake_flavor_Strawberry;
    inv->cake_flavor_Bluebury = cfg->cake_flavor_Bluebury;
    inv->sweet_flavor_Donut = cfg->sweet_flavor_Donut;
    inv->sweet_flavor_Croissant = cfg->sweet_flavor_Croissant;
    inv->sweet_flavor_Cookie = cfg->sweet_flavor_Cookie;
    inv->sweet_flavor_Cupcake = cfg->sweet_flavor_Cupcake;
    inv->bread_white=0;
    inv->bread_brown=1;
    inv->bread_ready = 6;
    inv->bread_white_ready = 10;
    inv->bread_brown_ready = 10;
    inv->total_cakes_ready_to_sell = 20;
    inv->total_sweets_ready_to_sell = 21;
    inv->total_sandwiches_ready_to_sell = 3;
    inv->total_sweet_patisseries_ready_to_sell = 12;
    inv->total_savory_patisseries_ready_to_sell = 5;
    inv->total_chocolate_cakes_ready_to_sell = 4;
    inv->total_vanilla_cakes_ready_to_sell = 4;
    inv->total_strawberry_cakes_ready_to_sell = 5;
    inv->total_blueburry_cakes_ready_to_sell = 5;
    inv->total_donut_sweets_ready_to_sell = 5;
    inv->total_croissant_sweets_ready_to_sell = 5;
    inv->total_cookie_sweets_ready_to_sell = 5;
    inv->total_cupcake_sweets_ready_to_sell = 5;
    inv->paste_ready = 3;

    inv->sandwich_salami_brown_count=1;
    inv->sandwich_salami_white_count=1;
    inv->sandwich_cheese_brown_count=1;
    inv->sandwich_cheese_white_count=1;
    inv->sandwich_both_white_count=1;
    inv->sandwich_both_brown_count=1;
    inv->sandwiches_ready=6;
   
     inv->frustrated_customers = 0;
    inv->frustrated_waiting = 0;
    inv->complaints = 0;
    inv->missing_requests = 0;
    inv->profit = 0;

    inv->swap_sweet_cake = 0;
    inv->swap_sweet_savory_pat = 0;
    inv->swap_paste_sandwich = 0;
    



}

void cleanup_pantry() {
    shmdt(inv);
    shmctl(shm_id, IPC_RMID, NULL);
}
