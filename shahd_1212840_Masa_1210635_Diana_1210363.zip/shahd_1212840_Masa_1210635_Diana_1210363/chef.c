#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "pantry.h"
#include <string.h>
#include <signal.h>

#define PASTE_TEAM 1
#define CAKE_TEAM 2
#define SANDWICH_TEAM 3
#define SWEET_TEAM 4
#define SWEET_PATISSERIE_TEAM 5
#define SAVORY_PATISSERIE_TEAM 6
#define MAX_CAKE 20
#define MAX_SANDWICH 20
#define MAX_PASTE 50
#define MAX_SWEET 15
#define MAX_SWEET_PATISSERIE 25
#define MAX_SAVORY_PATISSERIE 25
#define THRESHOLD 5
#define MAX_FLAVORS 3
#define MAX_FLAVOR_NAME 3
#define DELIVERY_DURATION 2.0f  

Inventory *inv;
int team_id;
int my_index;
volatile sig_atomic_t stop = 0;

void handle_sigterm(int sig) {
    stop = 1;
}
void handle_sigusr1(int sig) {
    team_id = inv->chef_team_ids[my_index];  
    printf("[Chef %d] Switched to team %d\n", getpid(), team_id);
}
volatile sig_atomic_t paused = 0;
int my_team_to_pause = -1;

void handle_sigusr2(int sig) {
    printf("[Chef %d] Received SIGUSR2 (pause/resume toggle).\n", getpid());
    fflush(stdout);
}



int read_cake_flavors_count() {
    FILE *file = fopen("config.txt", "r");
    if (!file) {
        perror("Failed to open config.txt");
        exit(1);
    }

    char line[256];
    int cake_flavors = 1;  // default 1 if not found
    while (fgets(line, sizeof(line), file)) {
        char key[100], value[150];
        if (sscanf(line, "%99[^=]=%149[^\n]", key, value) == 2) {
            if (strcmp(key, "cake_flavors") == 0) {
                cake_flavors = atoi(value);
                break;
            }
        }
    }
    fclose(file);
    return cake_flavors;
}
int read_sweet_flavors_count() {
    FILE *file = fopen("config.txt", "r");
    if (!file) {
        perror("Failed to open config.txt");
        exit(1);
    }

    char line[256];
    int sweet_flavors = 1;  // default 1 if not found
    while (fgets(line, sizeof(line), file)) {
        char key[100], value[150];
        if (sscanf(line, "%99[^=]=%149[^\n]", key, value) == 2) {
            if (strcmp(key, "sweet_flavors") == 0) {
                sweet_flavors = atoi(value);
                break;
            }
        }
    }
    fclose(file);
    return sweet_flavors;
}
int read_sandwich_types() {
    FILE *file = fopen("config.txt", "r");
    if (!file) {
        perror("Failed to open config.txt");
        exit(1);
    }

    char line[256];
    int sandwich_types = 1;  // default 1 if not found
    while (fgets(line, sizeof(line), file)) {
        char key[100], value[150];
        if (sscanf(line, "%99[^=]=%149[^\n]", key, value) == 2) {
            if (strcmp(key, "sandwich_types") == 0) {
                sandwich_types = atoi(value);
                break;
            }
        }
    }
    fclose(file);
    return sandwich_types;
}
int read_bread_types_count() {
    FILE *file = fopen("config.txt", "r");
    if (!file) {
        perror("Failed to open config.txt");
        exit(1);
    }

    char line[256];
    int bread_types = 1;  // default 1 if not found
    while (fgets(line, sizeof(line), file)) {
        char key[100], value[150];
        if (sscanf(line, "%99[^=]=%149[^\n]", key, value) == 2) {
            if (strcmp(key, "bread_types") == 0) {
                bread_types = atoi(value);
                break;
            }
        }
    }
    fclose(file);
    return bread_types;
}


int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Chef needs a team ID!\n");
        return 1;
    }
    signal(SIGTERM, handle_sigterm);  //  handle stop signal
    signal(SIGUSR1, handle_sigusr1);
    signal(SIGUSR2, handle_sigusr2);

    

    team_id = atoi(argv[1]);
    my_index = atoi(argv[2]);
    
    inv = init_pantry(0);
    sleep(1);  // Give some time for the manager to set up

    inv->chef_team_ids[my_index] = team_id;  // register your team in shared memory
    srand(getpid());
  //  read_cake_flavors();  // load the cake flavors
  int cake_flavors_count = read_cake_flavors_count();
  int sweet_flavors_count = read_sweet_flavors_count();
  int sandwich_types_selection =read_sandwich_types(); 
    int bread_types_count = read_bread_types_count();
        // Load the number of bread types
       
    printf("[Chef %d] I belong to team %d\n", getpid(), team_id);

    while (!stop) {
      
        for (int i = 0; i < 2 && !stop; i++) sleep(1); // safer sleep

        if (stop) break;
       
    //  Safe pause block that prevents semaphore use while paused
        while (inv->paused_team_ids[my_index]) {
            if (!paused) {
                paused = 1;
                printf("[Chef %d] Pausing due to shared pause flag.\n", getpid());
                fflush(stdout);
            }
            usleep(500000);  // 0.5s wait
        }
        // if we got here, we're not paused anymore
        if (paused) {
            paused = 0;
            printf("[Chef %d] Resuming due to shared resume flag.\n", getpid());
            fflush(stdout);
        }

        sleep(2 + rand() % 3);
   
   // === Handle sandwich block stopping ===
    if (team_id == SANDWICH_TEAM && (inv->cheese == 0 || inv->salami == 0)) {
        printf("[Chef %d] Out of cheese/salami. Pausing sandwich production.\n", getpid());
        sleep(2);  // Optional backoff or switch to idle
        continue;
    }

    if (team_id == PASTE_TEAM) {
        sem_wait(&inv->sem_paste);  //  Lock paste counter access first
        if (stop) {
            sem_post(&inv->sem_paste);
            break;
        }
    
        if (inv->paste_ready >= MAX_PASTE) {
            sem_post(&inv->sem_paste);  //  Unlock paste
            printf("[Chef %d] Paste storage full (%d). Waiting...\n", getpid(), inv->paste_ready);
            sleep(1);
            continue;
        }
    
        // Now check ingredients
        sem_wait(&inv->sem_base_ingredients);  //  Lock wheat, milk, yeast
        if (stop) {
            sem_post(&inv->sem_base_ingredients);
            break;
        }
        if (inv->wheat >= 1 && inv->yeast >= 1 && inv->milk >= 1) {
            inv->wheat--;
            inv->yeast--;
            inv->milk--;
            inv->paste_ready += 3;
    
            printf("[Chef %d] Prepared Paste! Paste ready: %d\n", getpid(), inv->paste_ready);
            fflush(stdout);
        } else {
            printf("[Chef %d] Not enough ingredients for Paste.\n", getpid());
            fflush(stdout);
        }
    
        sem_post(&inv->sem_base_ingredients);  //  Unlock base ingredients
        sem_post(&inv->sem_paste);             //  Unlock paste counter
    }
    
    
    else if (team_id == CAKE_TEAM) {
        sem_wait(&inv->sem_cake_flavors); //  LOCK
        if (stop) {
            sem_post(&inv->sem_cake_flavors);
            break;
        }
        if (inv->cakes_ready >= MAX_CAKE) {
            sem_post(&inv->sem_cake_flavors); //  UNLOCK before continue
            printf("[Chef %d] Cake storage full (%d). Waiting...\n", getpid(), inv->cakes_ready);
            fflush(stdout);
            sleep(1);
            continue;
        }
        sem_wait(&inv->sem_base_ingredients); //  LOCK base ingredients
        if (stop) {
            sem_post(&inv->sem_base_ingredients);
            break;
        }
        if (inv->milk >= 1 && inv->sugar >= 1 && inv->wheat >=1&&inv->sweet_items>= 1) {
            inv->milk--;
            inv->sugar--;
            inv->wheat--;
            inv->sweet_items--;
    
            int cake_flavor = rand() % cake_flavors_count;
            inv->cakes_ready++;
    
            if (cake_flavor == inv->cake_flavor_Chocolate) {
                inv->cake_chocolate_count++;
                printf("[Chef %d] Prepared paste for Chocolate Cake! Total Chocolate pastes: %d | Total cake pastes: %d\n",
                       getpid(), inv->cake_chocolate_count, inv->cakes_ready);
                fflush(stdout);
            }
            else if (cake_flavor == inv->cake_flavor_Vanilla) {
                inv->cake_vanilla_count++;
                printf("[Chef %d] Prepared paste for Vanilla Cake! Total Vanilla pastes: %d | Total cake pastes: %d\n",
                       getpid(), inv->cake_vanilla_count, inv->cakes_ready);
                fflush(stdout);
            }
            else if (cake_flavor == inv->cake_flavor_Strawberry) {
                inv->cake_strawberry_count++;
                printf("[Chef %d] Prepared paste for Strawberry Cake! Total Strawberry pastes: %d | Total cake pastes: %d\n",
                       getpid(), inv->cake_strawberry_count, inv->cakes_ready);
                fflush(stdout);
            }
            else if (cake_flavor == inv->cake_flavor_Bluebury) {
                inv->cake_blueburry_count++;
                printf("[Chef %d] Prepared paste for Blueberry Cake! Total Blueberry pastes: %d | Total cake pastes: %d\n",
                       getpid(), inv->cake_blueburry_count, inv->cakes_ready);
                fflush(stdout);
            }
        }
        else {
            printf("[Chef %d] Not enough milk/sugar for Cake.\n", getpid());
            fflush(stdout);
        }
    
        sem_post(&inv->sem_base_ingredients); //  UNLOCK
        sem_post(&inv->sem_cake_flavors); //  UNLOCK
    }
    
        
        else if (team_id == SANDWICH_TEAM) {
            sem_wait(&inv->sem_sandwich);  //  LOCK
            if (stop) {
                sem_post(&inv->sem_sandwich);
                break;
            }
            if (inv->sandwiches_ready >= MAX_SANDWICH) {
                sem_post(&inv->sem_sandwich); //  UNLOCK before continue
                printf("[Chef %d] Sandwich storage full (%d). Waiting...\n", getpid(), inv->sandwiches_ready);
                fflush(stdout);  //  ADD THIS 

                sleep(1);
                continue;
            }
        
            int sandwich_type = rand() % sandwich_types_selection;
            int bread_type = rand() % bread_types_count; // 0 = white, 1 = brown
            sem_wait(&inv->sem_bread_types);  //  LOCK bread types
            if (stop) {
                sem_post(&inv->sem_bread_types);
                break;
            }
            sem_wait(&inv->sem_cheese_salami);  //  LOCK base ingredients
            if (stop) {
                sem_post(&inv->sem_cheese_salami);
                break;
            }
            if (sandwich_type == inv->sandwich_type_cheese) {
                if (inv->bread_ready >= 1 && inv->cheese >= 1) {
                    inv->cheese--;
                    inv->sandwiches_ready++;
                    if(bread_type == inv->bread_white&&inv->bread_white_ready>0){ 
                        inv->bread_white_ready--;
                        inv->bread_ready--;
                        inv->sandwich_cheese_white_count++;
                        inv->sandwich_moving_index = my_index;
                        inv->sandwich_chef_is_delivering[my_index] = 1;
                        inv->sandwich_chef_timer[my_index] = DELIVERY_DURATION;


                        printf("[Chef %d] Prepared Sandwich with Cheese! and white bread Sandwiches ready: %d\n", getpid(), inv->sandwiches_ready);
                        fflush(stdout);  

                    }
                     else if(bread_type == inv->bread_brown&&inv->bread_brown_ready>0){
                        inv->bread_brown_ready--;
                        inv->bread_ready--;
                        inv->sandwich_cheese_brown_count++;
                        inv->sandwich_moving_index = my_index;
                        inv->sandwich_chef_is_delivering[my_index] = 1;
                        inv->sandwich_chef_timer[my_index] = DELIVERY_DURATION;

                        printf("[Chef %d] Prepared Sandwich with Cheese! and brown bread Sandwiches ready: %d\n", getpid(), inv->sandwiches_ready);
                        fflush(stdout); 

                    }
                    fflush(stdout);  

                } else {
                    printf("[Chef %d] Not enough Bread or Cheese for Cheese Sandwich.\n", getpid());
                    fflush(stdout);  

                }
            }
            else if (sandwich_type == inv->sandwich_type_salami) {
                if (inv->bread_ready >= 1 && inv->salami >= 1) {
                    inv->salami--;
                    inv->sandwiches_ready++;
                    if(bread_type == inv->bread_white&&inv->bread_white_ready>0){ 
                        inv->bread_white_ready--;
                        inv->bread_ready--;
                        inv->sandwich_salami_white_count++;
                        inv->sandwich_moving_index = my_index;
                        inv->sandwich_chef_is_delivering[my_index] = 1;
                        inv->sandwich_chef_timer[my_index] = DELIVERY_DURATION;

                        printf("[Chef %d] Prepared Sandwich with salami! and white bread Sandwiches ready: %d\n", getpid(), inv->sandwiches_ready);
                        fflush(stdout); 

                    } else if(bread_type == inv->bread_brown&&inv->bread_brown_ready>0){
                        inv->bread_brown_ready--;
                        inv->bread_ready--;
                        inv->sandwich_salami_brown_count++;
                        inv->sandwich_moving_index = my_index;
                        inv->sandwich_chef_is_delivering[my_index] = 1;
                        inv->sandwich_chef_timer[my_index] = DELIVERY_DURATION;


                        printf("[Chef %d] Prepared Sandwich with salami! and brown bread Sandwiches ready: %d\n", getpid(), inv->sandwiches_ready);
                        fflush(stdout);  

                    }

                } else {
                    printf("[Chef %d] Not enough Bread or Salami for Salami Sandwich.\n", getpid());
                    fflush(stdout); 

                }
            }
            else if (sandwich_type == inv->sandwich_type_both) {
                if (inv->cheese >= 1 && inv->salami >= 1 && inv->bread_ready >= 1) {
                    inv->cheese--;
                    inv->salami--;
                    inv->sandwiches_ready++;
                    if(bread_type == inv->bread_white&&inv->bread_white_ready>0){ 
                        inv->bread_white_ready--;
                        inv->bread_ready--;
                        inv->sandwich_both_white_count++;
                        inv->sandwich_moving_index = my_index;
                        inv->sandwich_chef_is_delivering[my_index] = 1;
                        inv->sandwich_chef_timer[my_index] = DELIVERY_DURATION;
                        
                        printf("[Chef %d] Prepared Sandwich with Cheese & salami! and white bread Sandwiches ready: %d\n", getpid(), inv->sandwiches_ready);
                        fflush(stdout);  

                    } else if(bread_type == inv->bread_brown&&inv->bread_brown_ready>0){
                        inv->bread_brown_ready--;
                        inv->bread_ready--;
                        inv->sandwich_both_brown_count++;
                        inv->sandwich_moving_index = my_index;
                        inv->sandwich_chef_is_delivering[my_index] = 1;
                        inv->sandwich_chef_timer[my_index] = DELIVERY_DURATION;


                        printf("[Chef %d] Prepared Sandwich with Cheese & salami! and brown bread Sandwiches ready: %d\n", getpid(), inv->sandwiches_ready);
                        fflush(stdout);  

                    }
                } else {
                    printf("[Chef %d] Not enough ingredients for Both Sandwich.\n", getpid());
                    fflush(stdout);  
                }
            }
        
            sem_post(&inv->sem_bread_types);  //  UNLOCK
            sem_post(&inv->sem_cheese_salami);  //  UNLOCK
            sem_post(&inv->sem_sandwich);  //  UNLOCK 
        }
        
        else if (team_id == SWEET_TEAM) {
            sem_wait(&inv->sem_sweet_flavors);  //  LOCK
            if (stop) {
                sem_post(&inv->sem_sweet_flavors);
                break;
            }
        
            if (inv->sweets_ready >= MAX_SWEET) {
                sem_post(&inv->sem_sweet_flavors); //  UNLOCK before continue
                printf("[Chef %d] Sweets storage full (%d). Waiting...\n", getpid(), inv->sweets_ready);
                fflush(stdout);
                sleep(1);
                continue;
            }
            sem_wait(&inv->sem_base_ingredients);  //  LOCK
            if (stop) {
                sem_post(&inv->sem_base_ingredients);
                break;
            }
            if (inv->milk >= 1 && inv->sugar >= 1 && inv->wheat >=1 && inv->butter>=1 &&inv->sweet_items>=1) {
                inv->milk--;
                inv->sugar--;
                inv->wheat--;
                inv->butter--;
                inv->sweet_items--;
        
                int sweet_flavor = rand() % sweet_flavors_count;
                inv->sweets_ready++;
        
                if (sweet_flavor == inv->sweet_flavor_Donut) {
                    inv->sweet_Donut_count++;
                    printf("[Chef %d] Prepared paste for Donut! Total Donut pastes: %d | Total sweet pastes: %d\n",
                           getpid(), inv->sweet_Donut_count, inv->sweets_ready);
                    fflush(stdout);
                }
                else if (sweet_flavor == inv->sweet_flavor_Croissant) {
                    inv->sweet_Croissant_count++;
                    printf("[Chef %d] Prepared paste for Croissant! Total Croissant pastes: %d | Total sweet pastes: %d\n",
                           getpid(), inv->sweet_Croissant_count, inv->sweets_ready);
                    fflush(stdout);
                }
                else if (sweet_flavor == inv->sweet_flavor_Cookie) {
                    inv->sweet_Cookie_count++;
                    printf("[Chef %d] Prepared paste for Cookie! Total Cookie pastes: %d | Total sweet pastes: %d\n",
                           getpid(), inv->sweet_Cookie_count, inv->sweets_ready);
                    fflush(stdout);
                }
                else if (sweet_flavor == inv->sweet_flavor_Cupcake) {
                    inv->sweet_Cupcake_count++;
                    printf("[Chef %d] Prepared paste for Cupcake! Total Cupcake pastes: %d | Total sweet pastes: %d\n",
                           getpid(), inv->sweet_Cupcake_count, inv->sweets_ready);
                    fflush(stdout);
                }
            }
            else {
                printf("[Chef %d] Not enough milk/sugar for Sweet.\n", getpid());
                fflush(stdout);
            }
        
            sem_post(&inv->sem_base_ingredients);  //  UNLOCK
            sem_post(&inv->sem_sweet_flavors);  //  UNLOCK
        }
        
        else if (team_id == SWEET_PATISSERIE_TEAM) {
            sem_wait(&inv->sem_sweet_patisserie);  //LOCK
            if (stop) {
                sem_post(&inv->sem_sweet_patisserie);
                break;
            }
            if (inv->sweet_patisseries_ready >= MAX_SWEET_PATISSERIE) {
                sem_post(&inv->sem_sweet_patisserie);  // UNLOCK

                printf("[Chef %d] Sweet patisserie storage full (%d). Waiting...\n", getpid(), inv->sweet_patisseries_ready);
                fflush(stdout);  

                sleep(1);
                continue;
            }
            sem_wait(&inv->sem_paste);  // LOCK
            if (stop) {
                sem_post(&inv->sem_paste);
                break;
            }
            sem_wait(&inv->sem_base_ingredients);  //  LOCK
            if (stop) {
                sem_post(&inv->sem_base_ingredients);
                break;
            }

            if (inv->paste_ready >= 1 && inv->sugar >= 1) {
                
            
                inv->paste_ready--;
                inv->sugar--;
                inv->sweet_patisseries_ready=inv->sweet_patisseries_ready+3;
                printf("[Chef %d] Prepared Sweet Patisserie! Sweet Patisseries ready: %d\n", getpid(), inv->sweet_patisseries_ready);
                fflush(stdout);  

            
        }
        else {
            printf("[Chef %d] Missing ingredients for Sweet Patisserie.\n", getpid());
            fflush(stdout);  

        }
        sem_post(&inv->sem_base_ingredients);  //  UNLOCK
        sem_post(&inv->sem_paste);  // UNLOCK
        sem_post(&inv->sem_sweet_patisserie);  //  UNLOCK
        }
        
      
        else if (team_id == SAVORY_PATISSERIE_TEAM) {
            sem_wait(&inv->sem_savory_patisserie);  //  LOCK
            if (stop) {
                sem_post(&inv->sem_savory_patisserie);
                break;
            }
            if (inv->savory_patisseries_ready >= MAX_SAVORY_PATISSERIE) {
                sem_post(&inv->sem_savory_patisserie);  //  UNLOCK
                printf("[Chef %d] Savory patisserie storage full (%d). Waiting...\n", getpid(), inv->savory_patisseries_ready);
                fflush(stdout);  

                sleep(1);
                continue;
            }
            sem_wait(&inv->sem_paste);  //  LOCK
            if (stop) {
                sem_post(&inv->sem_paste);
                break;
            }
            sem_wait(&inv->sem_salt);  // LOCK
            if (stop) {
                sem_post(&inv->sem_salt);
                break;
            }
            if (inv->paste_ready >= 1 && inv->salt >= 1) {
                inv->paste_ready--;
                inv->salt--;
                inv->savory_patisseries_ready=inv->savory_patisseries_ready+3;
                printf("[Chef %d] Prepared Savory Patisserie! Savory ready: %d\n", getpid(), inv->savory_patisseries_ready);
                fflush(stdout); 

            } else {
                printf("[Chef %d] Missing ingredients for Savory Patisserie.\n", getpid());
                fflush(stdout);  

            }
            sem_post(&inv->sem_salt);  
            sem_post(&inv->sem_paste);  
            sem_post(&inv->sem_savory_patisserie);  

        }
        if (stop) break;

    }


    return 0;
}
