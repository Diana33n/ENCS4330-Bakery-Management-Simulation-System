#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

int main() {
    srand(time(NULL) ^ getpid()); // Seed random

    // Array of item names
    const char* item_names[] = {
        "Wheat", "Yeast", "Butter", "Milk", "Sugar", "Salt",
        "Sweet Items", "Cheese", "Salami"
    };

    while (1) {
        int random_item = rand() % 9;        // Random item 0-8
        int added_units = (rand() % 5) + 1;   // Random units 1-5

        printf("[Test Supply Chain] Restocked %s with %d units.\n",
               item_names[random_item], added_units);

        sleep(3); // Sleep for 3 seconds to simulate action
    }

    return 0;
}
