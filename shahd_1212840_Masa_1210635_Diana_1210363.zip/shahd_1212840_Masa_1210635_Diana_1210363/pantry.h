#ifndef PANTRY_H
#define PANTRY_H

#include "config_parser.h"
#include <semaphore.h>
#define OVEN_COUNT 3 
#define SANDWICH_TEAM 3

#define MAX_CHEFS 12
#define MAX_BAKERS 3
#define MAX_sandwich_chefs 2


typedef struct {
    sem_t mutex; // semaphore for protecting inventory
    sem_t stats_mutex;  // Separate mutex for statistics
    
    int wheat;
    int yeast;
    int butter;
    int milk;
    int sugar;
    int salt;
    int sweet_items;
    int cheese;
    int salami;
    int paste_ready;
    int bread_ready;
    int bread_white_ready;
    int bread_brown_ready;
    int bread_white;
    int bread_brown;
    int cakes_ready;
    int cake_chocolate_count;
    int cake_vanilla_count;
    int cake_strawberry_count;
    int cake_blueburry_count;
    int cake_flavor_Chocolate;
    int cake_flavor_Vanilla;
    int cake_flavor_Strawberry;
    int cake_flavor_Bluebury;
    
    int sandwich_salami_brown_count;
    int sandwich_salami_white_count;
    
    int sandwich_cheese_brown_count;
    int sandwich_cheese_white_count;
    
    int sandwich_both_white_count;
    int sandwich_both_brown_count;
    
    int sandwiches_ready;
    int sweets_ready;
    int sandwich_type_cheese;
    int sandwich_type_salami;
    int sandwich_type_both;
    
    int sweet_flavor_Donut;
    int sweet_Donut_count;
    int sweet_flavor_Croissant;
    int sweet_Croissant_count;
    int sweet_flavor_Cookie;
    int sweet_Cookie_count;
    int sweet_flavor_Cupcake;
    int sweet_Cupcake_count;
    int sweet_patisseries_ready;
    int savory_patisseries_ready;
    
    int total_cakes_ready_to_sell;
    int total_sweets_ready_to_sell;
    int total_sandwiches_ready_to_sell;
    int total_sweet_patisseries_ready_to_sell;
    int total_savory_patisseries_ready_to_sell;
    int total_chocolate_cakes_ready_to_sell;
    int total_vanilla_cakes_ready_to_sell;
    int total_strawberry_cakes_ready_to_sell;
    int total_blueburry_cakes_ready_to_sell;
    int total_donut_sweets_ready_to_sell;
    int total_croissant_sweets_ready_to_sell;
    int total_cookie_sweets_ready_to_sell;
    int total_cupcake_sweets_ready_to_sell;
    //sandwich chef
    int sandwich_chef_is_delivering[MAX_sandwich_chefs];
    float sandwich_chef_timer[MAX_sandwich_chefs];
    int sandwich_moving_index; 
        
    //oven
    int ovens[OVEN_COUNT];             // 0 = free, 1 = busy
    int oven_in_use_by[OVEN_COUNT];  //  [1, -1, 3] means oven 0 = baker 1, oven 1 = unused, oven 2 = baker 3
    int baker_is_delivering[MAX_BAKERS]; 
    float baker_delivery_timer[MAX_BAKERS]; 
    
    sem_t oven_mutex[OVEN_COUNT];      // One semaphore per oven
    
    
    
    int profit;
    int frustrated_customers;
    int complaints;
    int missing_requests;
    
    
    
    
    
    // Prices
    int bread_price;
    int sandwich_price;
    int cake_price;
    int sweet_price;
    int patisserie_price;
    
    
    int msg_queue_id;
    // Tracking
    
    
    int target_profit;
    int max_frustrated_customers;
    int max_complaints;
    int max_missing_item_requests;
    int max_runtime_minutes;
    
    int frustrated_waiting;    // New counter for waiting frustration
    //Manger
    pid_t chef_pids[MAX_CHEFS];
    int paused_team_ids[MAX_CHEFS];  // 0 = active, 1 = paused
    int chef_team_ids[MAX_CHEFS];  // where index = chef local ID
    int chef_team_original_ids[MAX_CHEFS]; // 0 = cake, 1 = sweet, 2 = sandwich, 3 = patisserie
    int chef_prepared_count[MAX_CHEFS];  // tracks how many items each chef made


    pid_t baker_pids[MAX_BAKERS];
    int paused_bakerteam_ids[MAX_CHEFS];  // 0 = active, 1 = paused
    int baker_team_ids[MAX_CHEFS];  // where index = chef local ID
    int baker_team_original_ids[MAX_CHEFS]; // 0 = cake, 1 = sweet, 2 = sandwich, 3 = patisserie
    

    //mutex
    // Ingredient Group Mutexes
    sem_t sem_base_ingredients;     
    sem_t sem_cheese_salami;
    sem_t sem_salt;
    sem_t sem_paste;

    // Cake & Sweet Production Mutexes
    sem_t sem_cake_flavors;
    sem_t sem_total_cake_count;

    sem_t sem_sweet_flavors;
    sem_t sem_total_sweet_count;

    // Patisserie
    sem_t sem_sweet_patisserie;
    sem_t sem_total_sweet_patisserie;

    sem_t sem_savory_patisserie;
    sem_t sem_total_savory_patisserie;
    //sandwich
    // Sandwich
    sem_t sem_sandwich;

    // Bread
    sem_t sem_bread_types;
    //swaping
    int swap_sweet_cake;
    int swap_sweet_savory_pat;
    int swap_paste_sandwich;
    int swaped_chef[MAX_CHEFS];;
    //mutex_manager
    sem_t sem_manager;
    //opengl
    int num_customers;
    int num_sellers;
    int num_supply_chain; 
    int num_bakers;
    int num_chefs;
} Inventory;

// Functions to manage pantry
Inventory *init_pantry(int create);
void load_initial_stock(Inventory *inv, const Config *cfg);
void cleanup_pantry(void);



#endif // PANTRY_H
