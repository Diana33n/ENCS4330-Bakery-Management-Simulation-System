#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "pantry.h"

int main() {
    Inventory *inv = init_pantry(0); // connect to existing shared memory

    while (1) {
        lock_pantry();

        printf("\n------ Pantry Status ------\n");
        printf("Wheat: %d\n", inv->wheat);
        printf("Yeast: %d\n", inv->yeast);
        printf("Butter: %d\n", inv->butter);
        printf("Milk: %d\n", inv->milk);
        printf("Sugar: %d\n", inv->sugar);
        printf("Salt: %d\n", inv->salt);
        printf("Sweet items: %d\n", inv->sweet_items);
        printf("Cheese: %d\n", inv->cheese);
        printf("Salami: %d\n", inv->salami);
        printf("----------------------------\n");

        unlock_pantry();
        sleep(5); // نطبع كل 5 ثواني وضع المخزن
    }

    return 0;
}
