#ifndef CONFIG_PARSER_H
#define CONFIG_PARSER_H
typedef struct {
    int bread_types;
    int sandwich_types;
    int sandwich_type_cheese;
    int sandwich_type_salami;
    int sandwich_type_both;

    int cake_flavors;
    int cake_flavor_Chocolate;
    int cake_flavor_Vanilla;
    int cake_flavor_Strawberry;
    int cake_flavor_Bluebury;

    int sweet_flavors;
    int sweet_flavor_Donut;
    int sweet_flavor_Croissant;
    int sweet_flavor_Cookie;
    int sweet_flavor_Cupcake;

    int sweet_patisseries;
    int savory_patisseries;

    int num_chefs;
    int num_bakers;
    int num_sellers;
    int num_supply_chain;
    int num_customers;


    int wheat;
    int yeast;
    int butter;
    int milk;
    int sugar;
    int salt;
    int sweet_items;
    int cheese;
    int salami;

    int bread_price;
    int sandwich_price;
    int cake_price;
    int sweet_price;
    int patisserie_price;

    int target_profit;
    int max_frustrated_customers;
    int max_complaints;
    int max_missing_item_requests;
    int max_runtime_minutes;
} Config;

Config parse_config(const char *filename);

#endif // CONFIG_PARSER_H
