#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include "pantry.h"
#include <string.h>

#define CAKE_SWEET_BAKER_TEAM 1
#define PATISSERIE_BAKER_TEAM 2
#define BREAD_BAKER_TEAM 3
#define DELIVERY_DURATION 2.0f  // 2 seconds to "walk" toward Ready to Sell

int team_id;
int my_index;
volatile sig_atomic_t stop = 0;
volatile sig_atomic_t paused = 0;

int read_bread_types_count() {
    FILE *file = fopen("config.txt", "r");
    if (!file) {
        perror("Failed to open config.txt");
        exit(1);
    }

    char line[256];
    int bread_types = 1;  // default 1 if not found
    while (fgets(line, sizeof(line), file)) {
        char key[100], value[150];
        if (sscanf(line, "%99[^=]=%149[^\n]", key, value) == 2) {
            if (strcmp(key, "bread_types") == 0) {
                bread_types = atoi(value);
                break;
            }
        }
    }
    fclose(file);
    return bread_types;
}

void handle_sigterm(int sig) {
    stop = 1;
}
int reserve_oven(Inventory *inv, int baker_team_id) { 
    for (int i = 0; i < OVEN_COUNT; i++) {
        sem_wait(&inv->oven_mutex[i]);
        if (inv->ovens[i] == 0) {
            inv->ovens[i] = 1;
            inv->oven_in_use_by[i] = baker_team_id;  //  assign baker to oven
            sem_post(&inv->oven_mutex[i]);
            return i;
        }
        sem_post(&inv->oven_mutex[i]);
    }
    return -1;
}

void release_oven(Inventory *inv, int index) {
    sem_wait(&inv->oven_mutex[index]);
    inv->ovens[index] = 0;
    inv->oven_in_use_by[index] = -1;  // reset
    inv->baker_is_delivering[my_index] = 1;
inv->baker_delivery_timer[my_index] = DELIVERY_DURATION;  // e.g., 2.0f seconds

    sem_post(&inv->oven_mutex[index]);
}


void handle_sigusr2(int sig) {
    // Optional: just acknowledge signal
    printf("[Baker %d] Received SIGUSR2 (pause/resume toggle).\n", getpid());
    fflush(stdout);
}
int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Baker needs a team ID!\n");
        return 1;
    }
    
    signal(SIGTERM, handle_sigterm);  // Handle termination gracefully
    signal(SIGUSR2, handle_sigusr2);
    
    srand(getpid()); // Randomize based on PID
    
    int team_id = atoi(argv[1]);
    printf("[Baker %d] I belong to baking team %d\n", getpid(), team_id);
    
    Inventory *inv = init_pantry(0); // Attach to existing shared memory
    sleep(1);  // Give some time for the manager to set up
    int bread_types_count = read_bread_types_count(); // Load the number of bread types
    
    team_id = atoi(argv[1]);
    my_index = atoi(argv[2]);
    inv->baker_team_ids[my_index] = team_id;  // register your team in shared memory

    while (!stop) {
          
            sleep(1);

            while (inv->paused_bakerteam_ids[my_index]) {
                if (!paused) {
                    paused = 1;
                    printf("[Baker %d] Pausing due to shared pause flag.\n", getpid());
                    fflush(stdout);
                }
                usleep(500000);  // 0.5s wait
            }
            // if we got here, we're not paused anymore
            if (paused) {
                paused = 0;
                printf("[Chef %d] Resuming due to shared resume flag.\n", getpid());
                fflush(stdout);
            }
    
        // Refactored: Random flavor selection with fallback logic
if (team_id == CAKE_SWEET_BAKER_TEAM) {
    int baked = 0;
    int first_try = rand() % 2; // 0 = sweet first, 1 = cake first

    for (int attempt = 0; attempt < 2 && !baked; attempt++) {
        int try_type = (attempt == 0) ? first_try : 1 - first_try;

        if (try_type == 0) {
            // Try sweet
            sem_wait(&inv->sem_sweet_flavors);
            int available_sweets[4];
            int sweet_count = 0;
            if (inv->sweet_Donut_count > 0) available_sweets[sweet_count++] = 0;
            if (inv->sweet_Croissant_count > 0) available_sweets[sweet_count++] = 1;
            if (inv->sweet_Cookie_count > 0) available_sweets[sweet_count++] = 2;
            if (inv->sweet_Cupcake_count > 0) available_sweets[sweet_count++] = 3;

            if (sweet_count > 0) {
                int selected = available_sweets[rand() % sweet_count];
                int oven_index = reserve_oven(inv,CAKE_SWEET_BAKER_TEAM);
                if (oven_index == -1) {
                    sem_post(&inv->sem_sweet_flavors);
                    printf("[Baker %d] No oven available for Sweet. Waiting...\n", getpid());
                    sleep(1);
                    continue;
                }
                sem_wait(&inv->sem_total_sweet_count);
                
                const char *flavor = "";
                switch (selected) {
                    case 0: inv->sweet_Donut_count--; inv->total_donut_sweets_ready_to_sell+=3; flavor = "Donut"; break;
                    case 1: inv->sweet_Croissant_count--; inv->total_croissant_sweets_ready_to_sell+=3; flavor = "Croissant"; break;
                    case 2: inv->sweet_Cookie_count--; inv->total_cookie_sweets_ready_to_sell+=3; flavor = "Cookie"; break;
                    case 3: inv->sweet_Cupcake_count--; inv->total_cupcake_sweets_ready_to_sell+=3; flavor = "Cupcake"; break;
                }
                inv->sweets_ready--;
                sem_post(&inv->sem_sweet_flavors);
                printf("[Baker %d] Sweet %s entered oven %d\n", getpid(), flavor, oven_index);
                sleep(1);
                release_oven(inv, oven_index);
                inv->total_sweets_ready_to_sell+=3;

                sem_post(&inv->sem_total_sweet_count);
                baked = 1;
                sleep(1);

                printf("[Baker %d] Finished baking Sweet: %s\n", getpid(),flavor);
                printf("-> Total Sweets: %d\n", inv->total_sweets_ready_to_sell);
                printf("   Donut Sweets:     %d\n", inv->total_donut_sweets_ready_to_sell);
                printf("   Croissant Sweets: %d\n", inv->total_croissant_sweets_ready_to_sell);
                printf("   Cookie Sweets:    %d\n", inv->total_cookie_sweets_ready_to_sell);
                printf("   Cupcake Sweets:   %d\n", inv->total_cupcake_sweets_ready_to_sell);
                fflush(stdout);
            } else {
                sem_post(&inv->sem_sweet_flavors);
            }

        } else {
            // Try cake
            sem_wait(&inv->sem_cake_flavors);
            int available_cakes[4];
            int cake_count = 0;
            if (inv->cake_chocolate_count > 0) available_cakes[cake_count++] = 0;
            if (inv->cake_vanilla_count > 0) available_cakes[cake_count++] = 1;
            if (inv->cake_strawberry_count > 0) available_cakes[cake_count++] = 2;
            if (inv->cake_blueburry_count > 0) available_cakes[cake_count++] = 3;

            if (cake_count > 0) {
                int selected = available_cakes[rand() % cake_count];
                int oven_index = reserve_oven(inv,CAKE_SWEET_BAKER_TEAM);
                if (oven_index == -1) {
                    sem_post(&inv->sem_cake_flavors);
                    printf("[Baker %d] No oven available for Cake. Waiting...\n", getpid());
                    sleep(1);
                    continue;
                }
                sem_wait(&inv->sem_total_cake_count);

                const char *flavor = "";
                switch (selected) {
                    case 0: inv->cake_chocolate_count--; inv->total_chocolate_cakes_ready_to_sell++; flavor = "Chocolate"; break;
                    case 1: inv->cake_vanilla_count--; inv->total_vanilla_cakes_ready_to_sell++; flavor = "Vanilla"; break;
                    case 2: inv->cake_strawberry_count--; inv->total_strawberry_cakes_ready_to_sell++; flavor = "Strawberry"; break;
                    case 3: inv->cake_blueburry_count--; inv->total_blueburry_cakes_ready_to_sell++; flavor = "Blueberry"; break;
                }
                inv->cakes_ready--;
                sem_post(&inv->sem_total_cake_count);
                printf("[Baker %d] Cake %s entered oven %d\n", getpid(), flavor, oven_index);
                sleep(1);
                release_oven(inv, oven_index);
                inv->total_cakes_ready_to_sell++;
                sem_post(&inv->sem_cake_flavors);

                sleep(1);
                
                baked = 1;
                printf("[Baker %d] Finished baking Cake: %s\n", getpid(),flavor);
                printf("-> Total Cakes: %d\n", inv->total_cakes_ready_to_sell);
                printf("   Chocolate Cakes: %d\n", inv->total_chocolate_cakes_ready_to_sell);
                printf("   Vanilla Cakes:   %d\n", inv->total_vanilla_cakes_ready_to_sell);
                printf("   Strawberry Cakes:%d\n", inv->total_strawberry_cakes_ready_to_sell);
                printf("   Blueberry Cakes: %d\n", inv->total_blueburry_cakes_ready_to_sell);
                fflush(stdout);
            } else {
                sem_post(&inv->sem_cake_flavors);
            }
        }
    }

    if (!baked) {
        printf("[Baker %d] No cake or sweet paste available. Waiting...\n", getpid());
        sleep(1);
    }
}

else if (team_id == PATISSERIE_BAKER_TEAM) {
    int patisserie_type = rand() % 2; // 0 = sweet, 1 = savory
    int baked = 0;

    for (int i = 0; i < 2 && !baked; i++) {
        int type = (i == 0) ? patisserie_type : 1 - patisserie_type;

        if (type == 0) {
            sem_wait(&inv->sem_sweet_patisserie);
            if (inv->sweet_patisseries_ready >= 3) {
                int oven_index = reserve_oven(inv,PATISSERIE_BAKER_TEAM);
                if (oven_index == -1) {
                    sem_post(&inv->sem_sweet_patisserie);
                    printf("[Baker %d] No oven available. Waiting...\n", getpid());
                    sleep(1);
                    break;
                }

                inv->sweet_patisseries_ready -= 3;
                sem_post(&inv->sem_sweet_patisserie);
                printf("[Baker %d] Baked Sweet Patisserie in oven %d\n", getpid(), oven_index);
                sleep(1);
                release_oven(inv, oven_index);

                sem_wait(&inv->sem_total_sweet_patisserie);
                inv->total_sweet_patisseries_ready_to_sell += 3;
                sem_post(&inv->sem_total_sweet_patisserie);

                baked = 1;

                printf("[Baker %d] Total Sweet Patisseries Ready: %d\n", getpid(), inv->total_sweet_patisseries_ready_to_sell);
            } else {
                sem_post(&inv->sem_sweet_patisserie);
                printf("[Baker %d] Not enough Sweet Patisserie paste. Trying next...\n", getpid());
            }
        }

        else if (type == 1) {
            sem_wait(&inv->sem_savory_patisserie);
            if (inv->savory_patisseries_ready >= 3) {
                int oven_index = reserve_oven(inv,PATISSERIE_BAKER_TEAM);
                if (oven_index == -1) {
                    sem_post(&inv->sem_savory_patisserie);
                    printf("[Baker %d] No oven available. Waiting...\n", getpid());
                    sleep(1);
                    break;
                }

                inv->savory_patisseries_ready -= 3;
                sem_post(&inv->sem_savory_patisserie);
                printf("[Baker %d] Baked Savory Patisserie in oven %d\n", getpid(), oven_index);
                sleep(1);

                sem_wait(&inv->sem_total_savory_patisserie);
                inv->total_savory_patisseries_ready_to_sell += 3;
                sem_post(&inv->sem_total_savory_patisserie);
                release_oven(inv, oven_index);

                baked = 1;

                printf("[Baker %d] Total Savory Patisseries Ready: %d\n", getpid(), inv->total_savory_patisseries_ready_to_sell);
            } else {
                sem_post(&inv->sem_savory_patisserie);
                printf("[Baker %d] Not enough Savory Patisserie paste. Trying next...\n", getpid());
            }
        }
    }

    if (!baked) {
        printf("[Baker %d] No patisserie to bake. Waiting...\n", getpid());
        sleep(1);
    }
}

else if (team_id == BREAD_BAKER_TEAM) {
    sem_wait(&inv->sem_paste); //  Lock paste access
    if (inv->paste_ready > 0) {
        int oven_index = reserve_oven(inv,BREAD_BAKER_TEAM);
        if (oven_index == -1) {
            sem_post(&inv->sem_paste); //  Unlock before continue
            printf("[Baker %d] No oven available. for bread Waiting...\n", getpid());
            sleep(1);
            continue;
        }

        inv->paste_ready--;
        sem_post(&inv->sem_paste); //  Unlock after using paste

        int bread_type = rand() % bread_types_count;

        sem_wait(&inv->sem_bread_types);
        if (bread_type == inv->bread_white) {
            printf("[Baker %d] Baking White Bread in oven %d...\n", getpid(), oven_index);
            sleep(1);
            release_oven(inv, oven_index);
            inv->bread_white_ready += 3;
        } else {
            printf("[Baker %d] Baking Brown Bread in oven %d...\n", getpid(), oven_index);
            sleep(1);
            release_oven(inv, oven_index);
            inv->bread_brown_ready += 3;
        }
        inv->bread_ready += 3;
        sem_post(&inv->sem_bread_types);

        if (bread_type == inv->bread_white) {
            printf("[Baker %d] White Bread baked successfully! (Total White Breads Ready: %d)\n", getpid(), inv->bread_white_ready);
        } else {
            printf("[Baker %d] Brown Bread baked successfully! (Total Brown Breads Ready: %d)\n", getpid(), inv->bread_brown_ready);
        }
        printf("[Baker %d] Total Breads Ready: %d\n", getpid(), inv->bread_ready);
    } else {
        sem_post(&inv->sem_paste);  //  Unlock if no paste
        sleep(1);
    }
}

        else {
            printf("[Baker %d] Unknown team ID: %d\n", getpid(), team_id);
            sem_post(&inv->mutex);
            break;
        }
    }

    return 0;
}
