#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <errno.h>

#include <signal.h>
#include <time.h>
#include "pantry.h"
#include "config_parser.h"
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/msg.h>
#include "message.h"

#define SHM_KEY 0x1234
#define RUN_DURATION 60

pid_t *seller_pids;
pid_t *customer_pids;
pid_t *chef_pid;
pid_t *baker_pid;
pid_t *supplychain_pids;

pid_t display_pid = -1;

//  Now add these counters:
void cleanup_all(void);  // Function prototype
int num_sellers = 0;
int num_customers = 0;
int num_chefs = 0;
int num_bakers = 0;
int num_supplychains = 0;
pid_t  manager_pid;
//void create_chefs(int count);
void create_chefs(int count,Inventory *inv) ;
void create_bakers(int count,Inventory *inv);
void create_supply_chain(int count, const char *config_filename);
void print_inventory_status(Inventory *inv);
void check_missing_items(Inventory *inv);
void create_sellers(int count);
void create_customers(int count);
void terminate_simulation(Config cfg);
void start_manager();
void stop_manager();

//void cleanup_resources(int shm_id, int msg_id);
volatile sig_atomic_t stop = 0;

void handle_sigterm(int sig) {
    cleanup_all();  // Add this before any other code

    stop = 1;
}

void kill_processes(pid_t *pids, int count, const char *label);

int main(int argc, char *argv[]) {
    
    if (argc != 2) {
        printf("Usage: %s <config_file>\n", argv[0]);
        return 1;
    }
    
    Config cfg = parse_config(argv[1]);
    
    printf("Configuration loaded successfully.\n");
   
   
    int shm_id = shmget(SHM_KEY, sizeof(Inventory), 0666);
    if (shm_id != -1) {
        printf("Old shared memory found, deleting it...\n");
        shmctl(shm_id, IPC_RMID, NULL);
    }
    cleanup_all();  // Add this before any other code
    Inventory *inv = init_pantry(1);
    sleep(1);

    load_initial_stock(inv, &cfg);
    // Copy prices from config to shared memory
    inv->bread_price = cfg.bread_price;
    inv->sandwich_price = cfg.sandwich_price;
    inv->cake_price = cfg.cake_price;
    inv->sweet_price = cfg.sweet_price;
    inv->patisserie_price = cfg.patisserie_price;

    // Copy simulation parameters
    inv->target_profit = cfg.target_profit;
    inv->max_frustrated_customers = cfg.max_frustrated_customers;
    inv->max_complaints = cfg.max_complaints;
    inv->max_missing_item_requests = cfg.max_missing_item_requests;
    inv->max_runtime_minutes = cfg.max_runtime_minutes;
    inv->num_customers=cfg.num_customers;
    inv->num_sellers=cfg.num_sellers;
    inv->num_bakers=cfg.num_bakers;
    inv->num_chefs=cfg.num_chefs;
    
    // Allocate memory based on config
    seller_pids = malloc(sizeof(pid_t) * cfg.num_sellers);
    customer_pids = malloc(sizeof(pid_t) * cfg.num_customers);
    chef_pid = malloc(sizeof(pid_t) * cfg.num_chefs);
    baker_pid = malloc(sizeof(pid_t) * cfg.num_bakers);
    supplychain_pids = malloc(sizeof(pid_t) * cfg.num_supply_chain);

if (!seller_pids || !customer_pids || !chef_pid || !baker_pid || !supplychain_pids) {
    perror("Failed to allocate memory for PIDs");
    exit(1);
}



    printf("\n===== INITIAL INVENTORY STATUS =====\n");
    print_inventory_status(inv);
    // Create message queue
    usleep(300000);  // 300ms



    //  Now create a new message queue properly
    int msg_id = msgget(MSG_QUEUE_KEY, IPC_CREAT | 0666);
    if (msg_id == -1) {
        perror("Failed to create message queue");
        exit(1);
    }

    pid_t display_pid = fork();
    if (display_pid == 0) {
        // Child process: run the OpenGL displayer
        char *args[] = {"./bakery_display", "config.txt", NULL};
        execvp(args[0], args);
        // If exec fails
        perror("Failed to launch bakery_display");
        exit(1);
    } else if (display_pid < 0) {
        perror("Fork failed for bakery_display");
    }
    sleep(2); // Give the display process time to start
     
    // Create processes.
     start_manager();

    create_chefs(cfg.num_chefs,inv);
    create_bakers(cfg.num_bakers,inv);
    sleep(2);
    create_supply_chain(cfg.num_supply_chain, argv[1]);
    //sleep(2);
    create_sellers(cfg.num_sellers);

    // Wait a moment for sellers to initialize
    sleep(5);

    // Create customers (more than sellers to simulate queue)
    create_customers(cfg.num_customers);
    time_t start_time = time(NULL);

    while (!stop) {
        time_t now = time(NULL);
        int elapsed = (int)(now - start_time);
    
        printf("\n===== INVENTORY CHECK =====\n");
        print_inventory_status(inv);
        check_missing_items(inv);
    
        sem_wait(&inv->stats_mutex);
    
        if (inv->profit >= cfg.target_profit) {
            printf("\nTarget profit reached! (%d)\n", inv->profit);
            usleep(500000);
            sem_post(&inv->stats_mutex);
            terminate_simulation(cfg);
            break;
        }
    
        if ((inv->frustrated_customers+ inv->frustrated_waiting )>= cfg.max_frustrated_customers) {
            printf("\nToo many frustrated customers! (%d)\n", (inv->frustrated_customers+inv->frustrated_waiting));
            usleep(500000);
            sem_post(&inv->stats_mutex);
            terminate_simulation(cfg);
            break;
        }

    
        if (inv->complaints >= cfg.max_complaints) {
            printf("\nToo many complaints! (%d)\n", inv->complaints);
            usleep(500000);
            sem_post(&inv->stats_mutex);
            terminate_simulation(cfg);
            break;
        }
    
        if (inv->missing_requests >= 1) {
            printf("\nToo many missing item requests! (%d)\n", inv->missing_requests);
            usleep(500000);
            sem_post(&inv->stats_mutex);
            terminate_simulation(cfg);
            break;
        }
    
        if (elapsed >= cfg.max_runtime_minutes * 45) {
            printf("\nMaximum runtime reached! (%d minutes)\n", cfg.max_runtime_minutes);
            usleep(500000);
            sem_post(&inv->stats_mutex);
            terminate_simulation(cfg);
            break;
        }
    
        sem_post(&inv->stats_mutex);
        sleep(1);
    }
    printf("\n[MAIN] Simulation terminated. Cleaning up...\n");

    
    // Final status report
    printf("\n===== FINAL INVENTORY STATUS =====\n");
    printf("Ready Items:\n");
    printf("  Bread Ready: %d (White: %d, Brown: %d)\n",
           inv->bread_ready, inv->bread_white_ready, inv->bread_brown_ready);
    printf("  Cakes Ready: %d\n", inv->total_cakes_ready_to_sell);
    printf("  Sandwiches Ready: %d\n", inv->total_sandwiches_ready_to_sell);
    printf("  Sweets Ready: %d\n", inv->total_sweets_ready_to_sell);
    printf("  Sweet Patisseries Ready: %d\n", inv->total_sweet_patisseries_ready_to_sell);
    printf("  Savory Patisseries Ready: %d\n", inv->total_savory_patisseries_ready_to_sell);
    printf("\nBusiness Metrics:\n");
  
    printf("\n===== BUSINESS METRICS STATUS =====\n");
    printf("  Total Profit: %d\n", inv->profit);
    printf("  Frustrated Customers due to complains: %d\n", inv->frustrated_customers);
    printf("  Frustrated Customers due to waiting too long: %d\n", inv->frustrated_waiting);
    printf("  Complaints: %d\n", inv->complaints);
    printf("  Missing Item Requests: %d\n", inv->missing_requests);

          // simulation timeout
    printf("Simulation timeout reached. Ending...\n");
    
    kill(0, SIGTERM);     // Kill all child processes
    stop_manager();  //  cleanup

    sleep(1);             // Allow processes to exit
     while (wait(NULL) > 0);  // Wait for all child processes
     if (display_pid > 0) waitpid(display_pid, NULL, 0);

    // Then clean up resources
     msg_id = msgget(MSG_QUEUE_KEY, 0666); // Reopen
        if (msg_id != -1) {
        msgctl(msg_id, IPC_RMID, NULL);   // Remove the mq
        printf("Message queue removed successfully.\n");
    }
    //cleanup_business_metrics();
    cleanup_pantry();     
    // Free dynamically allocated PID arrays
    free(seller_pids);
    free(customer_pids);
    free(chef_pid);
    free(baker_pid);
    free(supplychain_pids);

    return 0;

}

void start_manager() {
      manager_pid = fork();
    if (manager_pid == 0) {
        execl("./manager", "manager", NULL);
        perror("Failed to launch manager");
        exit(1);
    }
}
void stop_manager() {
    if (manager_pid > 0) {
        kill(manager_pid, SIGTERM);
        waitpid(manager_pid, NULL, 0);
        printf("[Main] Manager process %d terminated.\n", manager_pid);
        fflush(stdout);
    }
}


void create_chefs(int count,Inventory *inv) {
    for (int i = 0; i < count; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            inv->chef_team_ids[i] = (i % 6) + 1; // Assign team ID to each chef
            inv->chef_team_original_ids[i] = (i % 6) + 1; // Assign original team ID to each chef
            char team_str[10], index_str[10];
            sprintf(team_str, "%d", (i % 6) + 1);
            sprintf(index_str, "%d", i);

            execl("./chef", "chef", team_str, index_str, NULL);  
            perror("Failed to launch chef");
            exit(1);
        } else if (pid > 0) {
            inv->chef_pids[i] = pid; // Save PID in shared memory
            chef_pid[i] = pid; //  Save PID
        } else {
            perror("Failed to fork chef");
        }
    }
}

void create_bakers(int count,Inventory *inv) {
    for (int i = 0; i < count; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            inv->baker_team_ids[i] = (i % 3) + 1; // Assign team ID to each baker
            inv->baker_team_original_ids[i] = (i % 3) + 1; // Assign original team ID to each baker

            char team_str[10],index_str[10];

            sprintf(team_str, "%d", (i % 3) + 1);
            sprintf(index_str, "%d", i);

            execl("./baker", "baker", team_str,index_str, NULL);
            perror("Failed to launch baker");
            exit(1);
        } else if (pid > 0) {
            inv->baker_pids[i] = pid; // Save PID in shared memory
            baker_pid[i] = pid; //  Save PID
        } else {
            perror("Failed to fork baker");
        }
    }
}
void create_supply_chain(int count, const char *config_filename){
    for (int i = 0; i < count; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            execl("./supply_chain", "supply_chain", config_filename, NULL);
            perror("Failed to launch supply chain worker");
            exit(1);
        } else if (pid > 0) {
            supplychain_pids[num_supplychains++] = pid;
        } else {
            perror("Failed to fork supply chain worker");
        }
    }
}


void create_sellers(int count) {
    for (int i = 0; i < count; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            execl("./seller", "seller", NULL);
            perror("Failed to launch seller");
            exit(1);
        } else if (pid > 0) {
            seller_pids[i] = pid;  //  Save the child PID
        } else {
            perror("Failed to fork seller");
        }
    }
}


void create_customers(int count) {
    for (int i = 0; i < count; i++) {
        pid_t pid = fork();
        if (pid == 0) {
            sleep(rand() % 3); // Stagger customer arrival
            execl("./customer", "customer", NULL);
            perror("Failed to launch customer");
            exit(1);
        } else if (pid > 0) {
            customer_pids[i] = pid;  //  Save the child PID
            
        } else {
            perror("Failed to fork customer");
        }
        sleep(1 + rand() % 4);  // Sleep 1–4 seconds between customers
    }
}


void print_inventory_status(Inventory *inv) {
    printf("Wheat: %d\n", inv->wheat);
    printf("Yeast: %d\n", inv->yeast);
    printf("Butter: %d\n", inv->butter);
    printf("Milk: %d\n", inv->milk);
    printf("Sugar: %d\n", inv->sugar);
    printf("Salt: %d\n", inv->salt);
    printf("Sweet Items: %d\n", inv->sweet_items);
    printf("Cheese: %d\n", inv->cheese);
    printf("Salami: %d\n", inv->salami);
}

void check_missing_items(Inventory *inv) {
    if (inv->wheat <= 0) printf("[Warning] Wheat is missing!\n");
    if (inv->yeast <= 0) printf("[Warning] Yeast is missing!\n");
    if (inv->butter <= 0) printf("[Warning] Butter is missing!\n");
    if (inv->milk <= 0) printf("[Warning] Milk is missing!\n");
    if (inv->sugar <= 0) printf("[Warning] Sugar is missing!\n");
    if (inv->salt <= 0) printf("[Warning] Salt is missing!\n");
    if (inv->sweet_items <= 0) printf("[Warning] Sweet Items are missing!\n");
    if (inv->cheese <= 0) printf("[Warning] Cheese is missing!\n");
    if (inv->salami <= 0) printf("[Warning] Salami is missing!\n");
}
void cleanup_all() {
    // 1. Kill all processes more aggressively
    system("pkill -9 chef baker seller customer supply_chain 2>/dev/null");

    // 2. Remove shared memory
    int shm_id = shmget(SHM_KEY, 0, 0666);
    if (shm_id != -1) {
        shmctl(shm_id, IPC_RMID, NULL);
    }

    // 3. Remove message queue
    int msg_id = msgget(MSG_QUEUE_KEY, 0666);
    if (msg_id != -1) {
        msgctl(msg_id, IPC_RMID, NULL);
    }

    //  Remove any semaphores left behind
    system("ipcs -s | awk 'NR > 3 {print $2}' | xargs -n1 ipcrm -s 2>/dev/null");
}
void kill_processes(pid_t *pids, int count, const char *label) {
    for (int i = 0; i < count; i++) {
        if (kill(pids[i], 0) == 0) {
            printf("Killing %s %d\n", label, pids[i]);
            kill(pids[i], SIGTERM);
            usleep(100000);  // let them clean up
            kill(pids[i], SIGKILL);  // force if still alive
        }
    }
}

void terminate_simulation(Config cfg ) {
    kill_processes(customer_pids, cfg.num_sellers * 5, "customer");
    kill_processes(seller_pids, cfg.num_sellers, "seller");
    kill_processes(chef_pid, cfg.num_chefs, "chef");
    kill_processes(baker_pid, cfg.num_bakers, "baker");
    kill_processes(supplychain_pids, cfg.num_supply_chain, "supply_chain");
    if (display_pid > 0) {
        printf("Killing displayer %d\n", display_pid);
        sleep(2);
        kill(display_pid, SIGTERM);
        usleep(100000);
        kill(display_pid, SIGKILL);
    }
    
    stop = 1;
}
