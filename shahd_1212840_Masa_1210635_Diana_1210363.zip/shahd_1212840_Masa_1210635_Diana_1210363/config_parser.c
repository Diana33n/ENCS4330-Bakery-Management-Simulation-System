#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "config_parser.h"

#define MAX_LINE 256
#define MAX_FLAVORS 10
#define MAX_FLAVOR_NAME 20

Config parse_config(const char *filename) {
    Config cfg;
    memset(&cfg, 0, sizeof(Config));  // initialize all fields to 0

    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Failed to open config file");
        exit(1);
    }

    char line[MAX_LINE];
    while (fgets(line, sizeof(line), file)) {
        char key[100], value[150];
        if (sscanf(line, "%99[^=]=%149[^\n]", key, value) == 2) {

            // Ingredient & quantity fields
            if (strcmp(key, "wheat") == 0) cfg.wheat = atoi(value);
            else if (strcmp(key, "yeast") == 0) cfg.yeast = atoi(value);
            else if (strcmp(key, "butter") == 0) cfg.butter = atoi(value);
            else if (strcmp(key, "milk") == 0) cfg.milk = atoi(value);
            else if (strcmp(key, "sugar") == 0) cfg.sugar = atoi(value);
            else if (strcmp(key, "salt") == 0) cfg.salt = atoi(value);
            else if (strcmp(key, "sweet_items") == 0) cfg.sweet_items = atoi(value);
            else if (strcmp(key, "cheese") == 0) cfg.cheese = atoi(value);
            else if (strcmp(key, "salami") == 0) cfg.salami = atoi(value);
            
            // Flavor counts
            else if (strcmp(key, "bread_types") == 0) cfg.bread_types = atoi(value);
            else if (strcmp(key, "sandwich_types") == 0) cfg.sandwich_types = atoi(value);
            else if (strcmp(key, "cake_flavors") == 0) cfg.cake_flavors = atoi(value);
            else if (strcmp(key, "sweet_flavors") == 0) cfg.sweet_flavors = atoi(value);
            else if (strcmp(key, "sweet_patisseries") == 0) cfg.sweet_patisseries = atoi(value);
            else if (strcmp(key, "savory_patisseries") == 0) cfg.savory_patisseries = atoi(value);
            //Cake flavors
            else if (strcmp(key, "cake_flavor_Chocolate") == 0) cfg.cake_flavor_Chocolate = atoi(value);
            else if (strcmp(key, "cake_flavor_Vanilla") == 0) cfg.cake_flavor_Vanilla = atoi(value);
            else if (strcmp(key, "cake_flavor_Strawberry") == 0) cfg.cake_flavor_Strawberry = atoi(value);
            else if (strcmp(key, "cake_flavor_Bluebury") == 0) cfg.cake_flavor_Bluebury = atoi(value);
            // Sweet flavors
            else if (strcmp(key, "sweet_flavor_Donut") == 0) cfg.sweet_flavor_Donut = atoi(value);
            else if (strcmp(key, "sweet_flavor_Croissant") == 0) cfg.sweet_flavor_Croissant = atoi(value);
            else if (strcmp(key, "sweet_flavor_Cookie") == 0) cfg.sweet_flavor_Cookie = atoi(value);
            else if (strcmp(key, "sweet_flavor_Cupcake") == 0) cfg.sweet_flavor_Cupcake = atoi(value);
            // Sandwich types
            else if (strcmp(key, "sandwich_type_cheese") == 0) cfg.sandwich_type_cheese = atoi(value);
            else if (strcmp(key, "sandwich_type_salami") == 0) cfg.sandwich_type_salami = atoi(value);
            else if (strcmp(key, "sandwich_type_both") == 0) cfg.sandwich_type_both = atoi(value);
            // Prices
            else if (strcmp(key, "bread_price") == 0) cfg.bread_price = atoi(value);
            else if (strcmp(key, "sandwich_price") == 0) cfg.sandwich_price = atoi(value);
            else if (strcmp(key, "cake_price") == 0) cfg.cake_price = atoi(value);
            else if (strcmp(key, "sweet_price") == 0) cfg.sweet_price = atoi(value);
            else if (strcmp(key, "patisserie_price") == 0) cfg.patisserie_price = atoi(value);

            // Simulation settings
            else if (strcmp(key, "num_chefs") == 0) cfg.num_chefs = atoi(value);
            else if (strcmp(key, "num_bakers") == 0) cfg.num_bakers = atoi(value);
            else if (strcmp(key, "num_sellers") == 0) cfg.num_sellers = atoi(value);
            else if (strcmp(key, "num_supply_chain") == 0) cfg.num_supply_chain = atoi(value);
            else if (strcmp(key, "num_customers") == 0) cfg.num_customers = atoi(value);


            else if (strcmp(key, "target_profit") == 0) cfg.target_profit = atoi(value);
            else if (strcmp(key, "max_frustrated_customers") == 0) cfg.max_frustrated_customers = atoi(value);
            else if (strcmp(key, "max_complaints") == 0) cfg.max_complaints = atoi(value);
            else if (strcmp(key, "max_missing_item_requests") == 0) cfg.max_missing_item_requests = atoi(value);
            else if (strcmp(key, "max_runtime_minutes") == 0) cfg.max_runtime_minutes = atoi(value);

            // Cake flavor names
            else if (strcmp(key, "cake_flavor_names") == 0) {
                int count = 0;
                char *token = strtok(value, ",");
                while (token && count < MAX_FLAVORS) {
                    // Store directly into a global array if needed
                    // For now, just count them
                    count++;
                    token = strtok(NULL, ",");
                }
                cfg.cake_flavors = count;
            }
        }
    }

    fclose(file);
    return cfg;
}
