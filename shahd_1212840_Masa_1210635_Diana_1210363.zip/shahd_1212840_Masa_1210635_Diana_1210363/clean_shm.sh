#!/bin/bash

echo "🧼 Cleaning up unused shared memory segments..."

# Get all shared memory IDs
ipcs -m | awk 'NR>3 {print $2}' | while read shmid; do
    # Get number of attached processes
    nattch=$(ipcs -m -i "$shmid" | awk '/nattch/ {print $NF}')
    
    if [ "$nattch" -eq 0 ]; then
        echo "Removing SHMID $shmid (not attached to any process)"
        ipcrm -m "$shmid"
    else
        echo "Skipping SHMID $shmid (still attached: $nattch)"
    fi
done

echo "✅ Cleanup complete."
