#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include "pantry.h"

#define BLUE   "\x1B[34m"
#define ORANGE "\x1b[38;5;208m"
#define PURPLE "\x1b[35m"
#define RESET  "\x1b[0m"
#define CYAN "\x1B[36m"
#define MINT "\x1B[38;5;121m"
#define ROSE "\x1B[38;5;168m"

#define IMBALANCE_THRESHOLD 5
#define MAX_READY_STOCK 20
#define PASTE_TEAM 1
#define CAKE_TEAM 2
#define SANDWICH_TEAM 3
#define SWEET_TEAM 4
#define SWEET_PATISSERIE_TEAM 5
#define SAVORY_PATISSERIE_TEAM 6
#define BREAD_TEAM 3
volatile sig_atomic_t stop = 0;

void handle_sigterm(int sig) {
    stop = 1;
}

void pause_team(Inventory *inv,int team ) {
   
    for (int i = 0; i < MAX_CHEFS; i++) {
        sem_wait(&inv->sem_manager);
        if (inv->chef_team_ids[i] == team) {
            printf(PURPLE "[Manager] Too many items from team %d → Chef %d pausing.\n" RESET, team, inv->chef_pids[i]);
            fflush(stdout);
            inv->paused_team_ids[i] = 1;
            sem_post(&inv->sem_manager);
            kill(inv->chef_pids[i], SIGUSR2);
        }
        sem_post(&inv->sem_manager);

    }
}

void resume_team(Inventory *inv, int team) {
    for (int i = 0; i < MAX_CHEFS; i++) {
        sem_wait(&inv->sem_manager);
        if (inv->chef_team_ids[i] == team && inv->paused_team_ids[i] == 1) {
            inv->paused_team_ids[i] = 0;
            printf(BLUE "[Manager] Resuming Chef %d from team %d\n" RESET,inv->chef_pids[i], team);
            sem_post(&inv->sem_manager);
            fflush(stdout);
            kill(inv->chef_pids[i], SIGUSR2);  // optional signal to notify
        }
        sem_post(&inv->sem_manager);

    }
}
void pause_bread(Inventory *inv,int team ) {
    for (int i = 0; i < MAX_BAKERS; i++) {
        sem_wait(&inv->sem_manager);

        if (inv->baker_team_ids[i] == team) {
            printf(PURPLE "[Manager] Too many items from team %d → Baker %d pausing.\n" RESET, team, inv->baker_pids[i]);
            fflush(stdout);
            inv->paused_bakerteam_ids[i] = 1;
            sem_post(&inv->sem_manager);
            kill(inv->baker_pids[i], SIGUSR2);
        }
        sem_post(&inv->sem_manager);


    }
}

void resume_bread(Inventory *inv, int team) {
    for (int i = 0; i < MAX_BAKERS; i++) {
        sem_wait(&inv->sem_manager);
        if (inv->baker_team_ids[i] == team && inv->paused_bakerteam_ids[i] == 1) {
            inv->paused_bakerteam_ids[i] = 0;
            sem_post(&inv->sem_manager);
            printf(BLUE "[Manager] Resuming Baker %d from team %d\n" RESET,inv->baker_pids[i], team);
            fflush(stdout);
            kill(inv->baker_pids[i], SIGUSR2);  // optional signal to notify
        }
        sem_post(&inv->sem_manager);

    }
}
int main() {
    Inventory *inv = init_pantry(0);
    sleep(1); // Give time for inventory to initialize
    signal(SIGTERM, handle_sigterm);
    int Paste_chefs = 0;
    int Cake_chefs = 0;
    int Sandwich_chefs = 0; 
    int Sweet_chefs = 0;
    int Sweet_patisserie_chefs = 0;
    int Savory_patisserie_chefs = 0;
   
    for (int i =0; i<MAX_CHEFS; i++){
        if(inv->chef_team_ids[i] == CAKE_TEAM){
            Cake_chefs++;
        }
        if(inv->chef_team_ids[i] == PASTE_TEAM){
            Paste_chefs++;
        }
        if(inv->chef_team_ids[i] == SANDWICH_TEAM){
            Sandwich_chefs++;
        }
        if(inv->chef_team_ids[i] == SWEET_TEAM){
            Sweet_chefs++;
        }
        if(inv->chef_team_ids[i] == SWEET_PATISSERIE_TEAM){
            Sweet_patisserie_chefs++;
        }
        if(inv->chef_team_ids[i] == SAVORY_PATISSERIE_TEAM){
            Savory_patisserie_chefs++;
        }
    }
    while (!stop) {
        sleep(1);

        sem_wait(&inv->sem_paste);
        int paste = inv->paste_ready;
        sem_post(&inv->sem_paste);

        sem_wait(&inv->sem_total_sweet_patisserie);
        int sweet_patisseries = inv->total_sweet_patisseries_ready_to_sell;
        sem_post(&inv->sem_total_sweet_patisserie);

        sem_wait(&inv->sem_total_savory_patisserie);
        int savory_patisseries = inv->total_savory_patisseries_ready_to_sell;
        sem_post(&inv->sem_total_savory_patisserie);

       

        sem_wait(&inv->sem_total_cake_count);
        int cakes = inv->total_chocolate_cakes_ready_to_sell+
        inv->total_vanilla_cakes_ready_to_sell+inv->total_strawberry_cakes_ready_to_sell+
        inv->total_blueburry_cakes_ready_to_sell;

        sem_post(&inv->sem_total_cake_count);

        sem_wait(&inv->sem_total_sweet_count);
        int sweet = inv->total_donut_sweets_ready_to_sell+inv->total_cupcake_sweets_ready_to_sell
        +inv->total_croissant_sweets_ready_to_sell+inv->total_cookie_sweets_ready_to_sell;
        sem_post(&inv->sem_total_sweet_count);

        sem_wait(&inv->sem_sandwich);
        int sandwiches = inv->sandwich_cheese_white_count+inv->sandwich_cheese_brown_count+
        inv->sandwich_salami_white_count+inv->sandwich_salami_brown_count+
        inv->sandwich_both_white_count+inv->sandwich_both_brown_count;
        sem_post(&inv->sem_sandwich);

        sem_wait(&inv->sem_bread_types);
        int bread = inv->bread_brown_ready+inv->bread_white_ready;
        sem_post(&inv->sem_bread_types);

        printf(BLUE "[Manager] [Sweet: %d | Savory: %d | Paste: %d | Cakes: %d | Sweets: %d | Sandwiches: %d | Bread: %d]\n" RESET,
               sweet_patisseries, savory_patisseries, paste, cakes, sweet, sandwiches, bread);

       // Pause teams with excessive stock
       if (sweet_patisseries >= MAX_READY_STOCK) pause_team(inv, SWEET_PATISSERIE_TEAM); else resume_team(inv, SWEET_PATISSERIE_TEAM);
       if (savory_patisseries >= MAX_READY_STOCK) pause_team(inv, SAVORY_PATISSERIE_TEAM); else resume_team(inv, SAVORY_PATISSERIE_TEAM);
       if (paste >= MAX_READY_STOCK) pause_team(inv, PASTE_TEAM); else resume_team(inv, PASTE_TEAM);
       if (cakes >= MAX_READY_STOCK) pause_team(inv, CAKE_TEAM); else resume_team(inv, CAKE_TEAM);
       if (sandwiches >= MAX_READY_STOCK) pause_team(inv, SANDWICH_TEAM); else resume_team(inv, SANDWICH_TEAM);
       if (sweet >= MAX_READY_STOCK) pause_team(inv, SWEET_TEAM); else resume_team(inv, SWEET_TEAM);
        if (bread >= MAX_READY_STOCK) pause_bread(inv, BREAD_TEAM); else resume_bread(inv, BREAD_TEAM);
        
        int diff_sweet_cake = sweet - cakes;
     
        if (abs(diff_sweet_cake) >= IMBALANCE_THRESHOLD) {
            sem_wait(&inv->sem_manager);
            if (inv->swap_sweet_cake == 0) {
                inv->swap_sweet_cake = 1;
                sem_post(&inv->sem_manager);
                printf(MINT "[Manager] Entered swap_sweet_cake\n" RESET);
               int random_sweet= (rand() % Sweet_chefs)+1;
               int random_cake= (rand()%Cake_chefs)+1;
               printf(MINT "[Manager] Random value for sweet chefs -> cake : %d, Random value for cake chefs ->sweet: %d\n" RESET,random_sweet,random_cake);

            printf(ROSE "[Manager] Imbalance SWEET vs CAKE: %d\n" RESET, diff_sweet_cake);
            for (int i = 0; i < MAX_CHEFS; i++) {
                if (diff_sweet_cake > 0 && inv->chef_team_ids[i] == SWEET_TEAM) {
                    sem_wait(&inv->sem_manager);
                    inv->chef_team_ids[i] = CAKE_TEAM;
                    sem_post(&inv->sem_manager);

                    kill(inv->chef_pids[i], SIGUSR1);
                    printf(ROSE "[Manager] Chef %d switched SWEET → CAKE\n" RESET, inv->chef_pids[i]);
                    random_sweet--;
                    if (random_sweet == 0) {
                        sem_post(&inv->sem_manager);  // 🔥 Add this

                        break;
                    }
                } else if (diff_sweet_cake < 0 && inv->chef_team_ids[i] == CAKE_TEAM) {
                    sem_wait(&inv->sem_manager);
                    inv->chef_team_ids[i] = SWEET_TEAM;
                    kill(inv->chef_pids[i], SIGUSR1);
                    sem_post(&inv->sem_manager);
                    random_cake--;

                    printf(ROSE "[Manager] Chef %d switched CAKE → SWEET\n" RESET, inv->chef_pids[i]);
                    if (random_cake == 0) {
                        sem_post(&inv->sem_manager);  // 🔥 Add this

                        break;
                    }
                    
                }
            }
        }
        }else {
            sem_post(&inv->sem_manager);

            for (int i = 0; i < MAX_CHEFS; i++) {
               if( inv->chef_team_ids[i] !=inv->chef_team_original_ids[i]){
                if (inv->chef_team_ids[i] == SWEET_TEAM) {
                    inv->chef_team_ids[i] = CAKE_TEAM;
                    kill(inv->chef_pids[i], SIGUSR1);
                    printf(CYAN "[Manager] No imbalance SWEET vs CAKE, Returning the cake chef[%d] to its team, the diff: %d\n" RESET,inv->chef_pids[i], diff_sweet_cake);
                } else if (inv->chef_team_ids[i] == CAKE_TEAM) {
                    inv->chef_team_ids[i] = SWEET_TEAM;
                    kill(inv->chef_pids[i], SIGUSR1);   
                    printf(CYAN "[Manager] No imbalance SWEET vs CAKE, Returning the sweet chef[%d] to its team, the diff: %d\n" RESET,inv->chef_pids[i], diff_sweet_cake);
             }
         }
    }
}

        int diff_sandwich_paste = sandwiches - paste;
        if (abs(diff_sandwich_paste) >= IMBALANCE_THRESHOLD) {
            sem_wait(&inv->sem_manager);

            if (inv->swap_paste_sandwich == 0) {
                inv->swap_paste_sandwich = 1;
                sem_post(&inv->sem_manager);
                printf(MINT "[Manager] Entered swap_paste_sandwich\n" RESET);
                int random_paste= (rand()%Paste_chefs)+1;
               int random_sandwich= (rand() % Sandwich_chefs)+1;
               printf(MINT "[Manager] Random value for PASTE chefs -> SANDWICH : %d, Random value for SANDWICH chefs ->PASTE: %d\n" RESET,random_paste,random_sandwich);

            printf(ROSE "[Manager] Imbalance SANDWICH vs PASTE: %d\n" RESET, diff_sandwich_paste);
            for (int i = 0; i < MAX_CHEFS; i++) {
                if (diff_sandwich_paste > 0 && inv->chef_team_ids[i] == SANDWICH_TEAM) {
                    sem_wait(&inv->sem_manager);
                    inv->chef_team_ids[i] = PASTE_TEAM;
                    sem_post(&inv->sem_manager);

                    kill(inv->chef_pids[i], SIGUSR1);
                    printf(ROSE "[Manager] Chef %d switched SANDWICH → PASTE\n" RESET, inv->chef_pids[i]);
                    random_sandwich--;
                    if (random_sandwich == 0) {
                        sem_post(&inv->sem_manager);  // 🔥 Add this

                        break;
                    }
                } else if (diff_sandwich_paste < 0 && inv->chef_team_ids[i] == PASTE_TEAM) {
                    sem_wait(&inv->sem_manager);

                    inv->chef_team_ids[i] = SANDWICH_TEAM;
                    sem_post(&inv->sem_manager);

                    kill(inv->chef_pids[i], SIGUSR1);
                    printf(ROSE "[Manager] Chef %d switched PASTE → SANDWICH\n" RESET, inv->chef_pids[i]);
                    random_paste--;
                    if (random_paste == 0) {
                        sem_post(&inv->sem_manager);  // 🔥 Add this

                        break;
                    }               
                 }
            }
        }
        }else {
            sem_post(&inv->sem_manager);

            for (int i = 0; i < MAX_CHEFS; i++) {
                if(inv->chef_team_ids[i] !=inv->chef_team_original_ids[i]){
                if (inv->chef_team_ids[i] == SANDWICH_TEAM) {
                    inv->chef_team_ids[i] = PASTE_TEAM;
                    kill(inv->chef_pids[i], SIGUSR1);

                    printf(CYAN "[Manager] No imbalance SANDWICH vs PASTE, Returning the Paste chef[%d] to its team, the diff: %d\n" RESET,inv->chef_pids[i], diff_sandwich_paste);

                } else if (inv->chef_team_ids[i] == PASTE_TEAM) {
                    inv->chef_team_ids[i] = SANDWICH_TEAM;
                    kill(inv->chef_pids[i], SIGUSR1);  
                    printf(CYAN "[Manager] No imbalance SANDWICH vs PASTE, Returning the Sandwich chef[%d] to its team, the diff: %d\n" RESET,inv->chef_pids[i], diff_sandwich_paste); 
            }
        }
    }
}


        int diff_pat = sweet_patisseries - savory_patisseries;
        if (abs(diff_pat) >= IMBALANCE_THRESHOLD) {
            sem_wait(&inv->sem_manager);
            if (inv->swap_sweet_savory_pat == 0) {
                inv->swap_sweet_savory_pat = 1;
                sem_post(&inv->sem_manager);

                printf(MINT "[Manager] Entered swap_sweet_cake\n" RESET);
               int random_sweet_pat= (rand() % Sweet_patisserie_chefs)+1;
               int random_savory_pat= (rand()%Savory_patisserie_chefs)+1;
               printf(MINT "[Manager] Random value for sweet_pat chefs -> savory_pat : %d, Random value for savory_pat chefs -> sweet_pat: %d\n" RESET,random_sweet_pat,random_savory_pat);

            printf(ROSE "[Manager] Imbalance SWEET_PAT vs SAVORY_PAT: %d\n" RESET, diff_pat);
            for (int i = 0; i < MAX_CHEFS; i++) {
                if (diff_pat > 0 && inv->chef_team_ids[i] == SWEET_PATISSERIE_TEAM) {
                    sem_wait(&inv->sem_manager);
                    inv->chef_team_ids[i] = SAVORY_PATISSERIE_TEAM;
                    sem_post(&inv->sem_manager);

                    kill(inv->chef_pids[i], SIGUSR1);
                    printf(ROSE "[Manager] Chef %d switched SWEET_PAT → SAVORY_PAT\n" RESET, inv->chef_pids[i]);
                    random_sweet_pat--;
                    if(random_sweet_pat == 0) {
                        sem_post(&inv->sem_manager);  // 🔥 Add this

                        break;
                    }
                } else if (diff_pat < 0 && inv->chef_team_ids[i] == SAVORY_PATISSERIE_TEAM) {
                    sem_wait(&inv->sem_manager);
                    inv->chef_team_ids[i] = SWEET_PATISSERIE_TEAM;
                    sem_post(&inv->sem_manager);

                    kill(inv->chef_pids[i], SIGUSR1);
                    printf(ROSE "[Manager] Chef %d switched SAVORY_PAT → SWEET_PAT\n" RESET, inv->chef_pids[i]);
                    random_savory_pat--;
                    if(random_savory_pat == 0) {
                        sem_post(&inv->sem_manager);  // 🔥 Add this

                        break;
                    }
                }
            }
        }
    }else {
        sem_post(&inv->sem_manager);

            for (int i = 0; i < MAX_CHEFS; i++) {
               if(inv->chef_team_ids[i] !=inv->chef_team_original_ids[i]){
                if (inv->chef_team_ids[i] == SWEET_PATISSERIE_TEAM) {
                    inv->chef_team_ids[i] = SAVORY_PATISSERIE_TEAM;
                    kill(inv->chef_pids[i], SIGUSR1);
                    printf(CYAN "[Manager] No imbalance SWEET PAT vs SAVORY PAT, Returning the SAVORY PAT chef[%d] to its team, the diff: %d\n" RESET,inv->chef_pids[i], diff_pat);
                } else if (inv->chef_team_ids[i] == SAVORY_PATISSERIE_TEAM) {
                    inv->chef_team_ids[i] = SWEET_PATISSERIE_TEAM;
                    kill(inv->chef_pids[i], SIGUSR1);   
                    printf(CYAN "[Manager] No imbalance SWEET PAT vs SAVORY PAT, Returning the SWEET PAT chef[%d] to its team, the diff: %d\n" RESET,inv->chef_pids[i], diff_pat);
          }
        }
    }
}
sem_post(&inv->sem_manager);

    }

    return 0;
}
