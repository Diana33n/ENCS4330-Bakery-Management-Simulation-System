#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <sys/msg.h>
#include <signal.h>
#include <errno.h>
#include "pantry.h"
#include "message.h"
#include <string.h>

#define GREEN   "\x1B[32m"
#define RED     "\x1B[31m"
#define RESET   "\x1B[0m"

volatile sig_atomic_t stop = 0;
static int msgid;

void handle_sigterm(int sig) {
    stop = 1;
}

void send_customer_state(int state, const char* items, int timeout) {
    CustomerStateMessage msg;
    msg.mtype = MSG_TYPE_CUSTOMER_STATE;
    msg.customer_pid = getpid();
    msg.state = state;
    strncpy(msg.items, items, sizeof(msg.items)-1);
    msg.timeout = timeout;

    if (msgsnd(msgid, &msg, sizeof(CustomerStateMessage) - sizeof(long), 0) ){
        perror("msgsnd failed for customer state");
    }
}

ItemType select_item_type() {
    return rand() % 5;
}

const char* bread_type_to_str(BreadType type) {
    return type == WHITE ? "White" : "Brown";
}

const char* sandwich_type_to_str(SandwichType type) {
    switch(type) {
        case CHEESE: return "Cheese";
        case SALAMI: return "Salami";
        case BOTH: return "Cheese & Salami";
        default: return "Unknown";
    }
}

const char* cake_flavor_to_str(CakeFlavor flavor) {
    switch(flavor) {
        case CHOCOLATE: return "Chocolate";
        case VANILLA: return "Vanilla";
        case STRAWBERRY: return "Strawberry";
        case BLUEBERRY: return "Blueberry";
        default: return "Unknown";
    }
}

const char* sweet_flavor_to_str(SweetFlavor flavor) {
    switch(flavor) {
        case DONUT: return "Donut";
        case CROISSANT: return "Croissant";
        case COOKIE: return "Cookie";
        case CUPCAKE: return "Cupcake";
        default: return "Unknown";
    }
}

const char* patisserie_type_to_str(PatisserieType type) {
    return type == SWEET_PAT ? "Sweet" : "Savory";
}

void generate_request(CustomerRequest *req) {
    req->mtype = MSG_TYPE_CUSTOMER_REQUEST;
    req->customer_pid = getpid();
    req->num_items = 1 + rand() % MAX_ITEMS_PER_ORDER;
    req->timestamp = time(NULL);
    req->timeout = 3 + (rand() % 8);

    for (int i = 0; i < req->num_items; i++) {
        req->items[i].item_type = select_item_type();
        req->items[i].quantity = 1 + rand() % 2;

        switch(req->items[i].item_type) {
            case BREAD:
                req->items[i].details.bread_type = rand() % 2 ? WHITE : BROWN;
                break;
            case SANDWICH:
                req->items[i].details.sandwich.sandwich_type = rand() % 3;
                req->items[i].details.sandwich.bread_type = rand() % 2 ? WHITE : BROWN;
                break;
            case CAKE:
                req->items[i].details.cake_flavor = rand() % 4;
                break;
            case SWEET:
                req->items[i].details.sweet_flavor = rand() % 4;
                break;
            case PATISSERIE:
                req->items[i].details.patisserie_type = rand() % 2 ? SWEET_PAT : SAVORY_PAT;
                break;
        }
    }
}

void print_request_details(const CustomerRequest *req) {
    printf(GREEN "[Customer %d] Request Details (%d items):\n" RESET, getpid(), req->num_items);

    for (int i = 0; i < req->num_items; i++) {
        printf(GREEN "  Item %d:\n" RESET, i+1);
        printf(GREEN "    Type: " RESET);

        switch(req->items[i].item_type) {
            case BREAD:
                printf(GREEN "Bread (%s)\n" RESET, bread_type_to_str(req->items[i].details.bread_type));
                break;
            case SANDWICH:
                printf(GREEN "Sandwich - Type: %s, Bread: %s\n" RESET,
                       sandwich_type_to_str(req->items[i].details.sandwich.sandwich_type),
                       bread_type_to_str(req->items[i].details.sandwich.bread_type));
                break;
            case CAKE:
                printf(GREEN "Cake (%s)\n" RESET, cake_flavor_to_str(req->items[i].details.cake_flavor));
                break;
            case SWEET:
                printf(GREEN "Sweet (%s)\n" RESET, sweet_flavor_to_str(req->items[i].details.sweet_flavor));
                break;
            case PATISSERIE:
                printf(GREEN "Patisserie (%s)\n" RESET, patisserie_type_to_str(req->items[i].details.patisserie_type));
                break;
        }
        printf(GREEN "    Quantity: %d\n" RESET, req->items[i].quantity);
    }
}

char* build_items_string(const CustomerRequest *req, const SellerResponse *resp) {
    static char items_str[256];
    items_str[0] = '\0';

    for (int i = 0; i < req->num_items; i++) {
        if (i > 0) strcat(items_str, ", ");

        switch(req->items[i].item_type) {
            case BREAD:
                strcat(items_str, bread_type_to_str(req->items[i].details.bread_type));
                strcat(items_str, " Bread");
                break;
            case SANDWICH:
                strcat(items_str, sandwich_type_to_str(req->items[i].details.sandwich.sandwich_type));
                strcat(items_str, " Sandwich on ");
                strcat(items_str, bread_type_to_str(req->items[i].details.sandwich.bread_type));
                break;
            case CAKE:
                strcat(items_str, cake_flavor_to_str(req->items[i].details.cake_flavor));
                strcat(items_str, " Cake");
                break;
            case SWEET:
                strcat(items_str, sweet_flavor_to_str(req->items[i].details.sweet_flavor));
                break;
            case PATISSERIE:
                strcat(items_str, patisserie_type_to_str(req->items[i].details.patisserie_type));
                strcat(items_str, " Patisserie");
                break;
        }

        char item_status[20];
        if (resp == NULL || (resp != NULL && resp->item_success[i])) {
            sprintf(item_status, " x%d✓", req->items[i].quantity);
        } else {
            sprintf(item_status, " x%d✗", req->items[i].quantity);
        }
        strcat(items_str, item_status);
    }

    return items_str;
}
int main() {
    signal(SIGTERM, handle_sigterm);
    srand(getpid() * time(NULL));

    msgid = msgget(MSG_QUEUE_KEY, 0666);
    if (msgid == -1) {
        perror("msgget failed");
        exit(1);
    }

    printf(GREEN "\n[Customer %d] Entered the bakery\n" RESET, getpid());
    send_customer_state(CUSTOMER_ENTERING, "Entering", 0);

    CustomerRequest req;
    SellerResponse resp;
    int request_sent = 0;
    int heard_complaint = 0;
    int resp_received = 0;

    // Entering state - just wait a moment
    sleep(1);

    while (!stop) {
        // Check for complaints from other customers
        ComplaintMessage complaint;
        if (msgrcv(msgid, &complaint, sizeof(ComplaintMessage) - sizeof(long), MSG_TYPE_COMPLAINT, IPC_NOWAIT) != -1) {
            heard_complaint = 1;
            
            int leave_chance = 20 * complaint.severity;
            if (rand() % 100 < leave_chance) {
                printf(RED "  DECISION: Leaving bakery due to complaint\n" RESET);
                printf(RED "  Chance to leave: %d%%\n\n" RESET, leave_chance);

                FrustrationUpdateMessage frust_msg;
                frust_msg.mtype = MSG_TYPE_FRUSTRATION_UPDATE;
                frust_msg.frustrated_count = 1;

                msgsnd(msgid, &frust_msg, sizeof(FrustrationUpdateMessage) - sizeof(long), 0);
                send_customer_state(CUSTOMER_FRUSTRATED_EXIT, "Left due to complaint", 0);
                stop = 1;
                break;
            }
        }

        if (!request_sent && !heard_complaint) {
            // Move to ordering position
            send_customer_state(CUSTOMER_ORDERING, "Placing order", 0);
            sleep(1); // Time to "place order"

            generate_request(&req);
            print_request_details(&req);

            char* items_str = build_items_string(&req, NULL);
            if (msgsnd(msgid, &req, sizeof(CustomerRequest) - sizeof(long), 0) == -1) {
                perror("msgsnd failed");
                continue;
            }

            request_sent = 1;
            printf(GREEN "\n[Customer %d] ORDER PLACED:\n" RESET, getpid());
            printf(GREEN "  Timeout: %d seconds\n" RESET, req.timeout);
            printf(GREEN "  Waiting for response...\n\n" RESET);

            // Move to waiting position
            send_customer_state(CUSTOMER_WAITING, items_str, req.timeout);
        }

        time_t start_wait = time(NULL);
        while (time(NULL) - start_wait < req.timeout && !stop && request_sent ) {
            // Check for complaints while waiting
          

            if (msgrcv(msgid, &resp, sizeof(SellerResponse) - sizeof(long), getpid(), IPC_NOWAIT) == -1) {
                if (errno == ENOMSG) {
                    sleep(1);
                    continue;
                }
                perror("msgrcv failed");
                break;
            }

            resp_received = 1;

            printf(GREEN "\n[Customer %d] ORDER RESULT:\n" RESET, getpid());
            char* items_str = build_items_string(&req, &resp);

            // Move to service position
            send_customer_state(CUSTOMER_BEING_SERVED, items_str, req.timeout);
            sleep(1); // Time to "be served"

            if (resp.success) {
                printf(GREEN "  STATUS: Full success!\n" RESET);
                printf(GREEN "  Total price: %d\n" RESET, resp.total_price);

                for (int i = 0; i < req.num_items; i++) {
                    printf(GREEN "  Item %d: %d purchased, %d remaining\n" RESET,
                           i+1, req.items[i].quantity, resp.remaining_stocks[i]);
                }

                // 10% chance to complain
                if (rand() % 10 == 0) {
                    printf(RED "\n[Customer %d] DISSATISFIED WITH ORDER!\n" RESET, getpid());
                    printf(RED "  Requesting full refund of %d\n\n" RESET, resp.total_price);

                    CustomerComplaintMessage cust_complaint = {
                        .mtype = MSG_TYPE_CUSTOMER_COMPLAINT,
                        .customer_pid = getpid(),
                        .total_price = resp.total_price
                    };
                    msgsnd(msgid, &cust_complaint, sizeof(CustomerComplaintMessage) - sizeof(long), 0);

                    // Broadcast to other customers
                    ComplaintMessage broadcast = {
                        .mtype = MSG_TYPE_COMPLAINT,
                        .severity = 1 + rand() % 3
                    };
                    msgsnd(msgid, &broadcast, sizeof(ComplaintMessage) - sizeof(long), IPC_NOWAIT);

                    // Move to refund position
                    send_customer_state(CUSTOMER_REFUND_PROCESSING, "Requesting refund", req.timeout);
                    sleep(1); // Time to "process refund"

                    // Wait for refund acknowledgment
                    RefundAckMessage ack;
                    printf(RED "[Customer %d] AWAITING REFUND...\n" RESET, getpid());
                    if (msgrcv(msgid, &ack, sizeof(RefundAckMessage) - sizeof(long), getpid(), 0) == -1) {
                        perror("Failed to receive refund ack");
                    } else {
                        printf(RED "\n[Customer %d] REFUND RECEIVED:\n" RESET, getpid());
                        printf(RED "  Amount: %d\n" RESET, ack.amount);
                        printf(RED "  Status: Full refund processed\n\n" RESET);
                    }
                    send_customer_state(CUSTOMER_FRUSTRATED_EXIT, "Refund processed", 0);
                } else {
                    send_customer_state(CUSTOMER_HAPPY_EXIT, items_str, req.timeout);
                }
            } else {
                printf(GREEN "  STATUS: Partial success\n" RESET);
                printf(GREEN "  Total price: %d\n" RESET, resp.total_price);

                for (int i = 0; i < req.num_items; i++) {
                    if (resp.item_success[i]) {
                        printf(GREEN "  Item %d: Purchased %d, %d remaining\n" RESET,
                               i+1, req.items[i].quantity, resp.remaining_stocks[i]);
                    } else {
                        printf(RED "  Item %d: Failed (requested %d, available %d)\n" RESET,
                               i+1, req.items[i].quantity, resp.remaining_stocks[i]);
                    }
                }
                send_customer_state(CUSTOMER_HAPPY_EXIT, items_str, req.timeout);
            }
            stop = 1;
            break;
        }

if (!stop && time(NULL) - start_wait >= req.timeout && request_sent && !resp_received) {
    printf(RED "\n[Customer %d] TIMEOUT REACHED:\n" RESET, getpid());
    printf(RED "  Waited %d seconds\n" RESET, req.timeout);
    printf(RED "  Leaving frustrated!\n\n" RESET);

    // Send cancellation message to seller
    RequestCancellationMessage cancel_msg = {
        .mtype = MSG_TYPE_REQUEST_CANCELLATION,
        .customer_pid = getpid(),
        .request_timestamp = req.timestamp
    };
    msgsnd(msgid, &cancel_msg, sizeof(RequestCancellationMessage) - sizeof(long), 0);

    FrustrationUpdateMessage frust_msg = {
        .mtype = MSG_TYPE_FRUSTRATION_EXIT,
        .frustrated_count = 1
    };
    msgsnd(msgid, &frust_msg, sizeof(FrustrationUpdateMessage) - sizeof(long), 0);
    send_customer_state(CUSTOMER_FRUSTRATED_EXIT, "Timed out", req.timeout);
    stop = 1;
}
   }

    printf(GREEN "[Customer %d] Left the bakery\n\n" RESET, getpid());
    return 0;
}