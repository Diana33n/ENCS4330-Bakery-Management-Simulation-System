#include <GL/glut.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h>
#include <time.h>
#include "pantry.h"
#include <unistd.h>
#include "message.h"
#include <sys/msg.h>


#define SANDWICH_TEAM 3

#define MSG_QUEUE_KEY 0x12345
#define SHM_KEY 0x1234

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#define MAX_SUPPLIERS 20
#define SUPPLIER_SCALE  0.75f
// Global state
#define NUM_ITEMS 9
#define NUM_SELLERS 2
#define MAX_CUSTOMERS 10
#define MAX_SELLERS 20
#define PASTE_TEAM 1
#define CAKE_TEAM 2
#define SANDWICH_TEAM 3
#define SWEET_TEAM 4
#define SWEET_PATISSERIE_TEAM 5
#define SAVORY_PATISSERIE_TEAM 6
#define SWAP_MSG_DURATION 60  // number of frames to keep the message

int swap_message_timer = 0;
char current_swap_msg[64] = "";

static char current_pause_msg[64] = "";
static int pause_message_timer = 0;
static int prev_paused_state[MAX_CHEFS] = {0};  // To detect new pause
static int prev_paused_baker[MAX_BAKERS] = {0}; // For bakers


static int frame_counter = 0;

int blink_flag = 0;  
float arm_angle = 0.0f;


static int prev_salami_white = 0;
static int prev_salami_brown = 0;
static int prev_cheese_white = 0;
static int prev_cheese_brown = 0;
static int prev_both_white = 0;
static int prev_both_brown = 0;

static void fatal(const char *ctx);
static int msgid;
static float sandwich_chef_x[MAX_CHEFS] = {0};  // Track X position of each chef
static float sandwich_chef_y[MAX_CHEFS] = {0};  // Track Y position
static int sandwich_moving[MAX_CHEFS] = {0};    // 1 if moving toward ready panel


// Customer state definitions
#define CUSTOMER_ENTERING 0
#define CUSTOMER_WAITING 1
#define CUSTOMER_BEING_SERVED 2
#define CUSTOMER_HAPPY_EXIT 3
#define CUSTOMER_FRUSTRATED_EXIT 4
#define CUSTOMER_REFUND_PROCESSING 5

// Customer zones layout
typedef struct {
    float enter_x, enter_y;    // Entry point
    float request_x, request_y; // Ordering area
    float wait_x, wait_y;      // Waiting queue
    float serve_x, serve_y;    // Service counters
    float refund_x, refund_y;  // Refund area
    float exit_x, exit_y;      // Exit point
} CustomerZones;

static CustomerZones zones = {
    .enter_x = -0.9f, .enter_y = -0.6f,    // Left side entrance
    .request_x = -0.5f, .request_y = -0.6f, // Order desk
    .wait_x = -0.2f, .wait_y = -0.6f,      // Waiting area
    .serve_x = 0.2f, .serve_y = -0.6f,     // Service counters
    .refund_x = 0.5f, .refund_y = -0.6f,   // Manager's desk
    .exit_x = 0.8f, .exit_y = -0.6f        // Right side exit
};


static Inventory *inv = NULL;
static int msgid;
static float customer_positions[MAX_CUSTOMERS][2] = {0};
static int customer_states[MAX_CUSTOMERS] = {0}; // 0=waiting, 1=being served, 2=leaving happy, 3=leaving frustrated
static float customer_animations[MAX_CUSTOMERS] = {0};
static char customer_items[MAX_CUSTOMERS][100] = {0};
static float supplier_pos[MAX_SUPPLIERS][2];
static int   supplier_state[MAX_SUPPLIERS];   // 0=at stock,1=to inventory,2=restock,3=return
static float supplier_anim[MAX_SUPPLIERS];
static float supplier_target[ MAX_SUPPLIERS ][2];
static int supplier_box_idx[MAX_SUPPLIERS] = {0};

static const float SUP_LEFT_X   = -0.95f; 
static const float SUP_RIGHT_X  = -0.90f;  
static const float SUP_BASE_Y   = -0.3f;  
static const float SUP_SPEED    =  0.01f;



typedef struct {
    pid_t pid;
    int state;
    int prev_state;
    char items[256];
    float x, y;
    float animation;
    time_t last_update;
    int timeout;
    int refund_amount;
    int queue_position;  // Position in the specific state's queue
    time_t state_time;
} CustomerTracking;

static CustomerTracking customers[MAX_CUSTOMERS];
static int num_tracked_customers = 0;

//////////////////////////////////////////////////////////////////
// Modify the seller_states array definition:
typedef struct {
    pid_t pid;
    int state;  // 0=idle, 1=serving, 2=processing payment, 3=processing refund
    char status[128];
    float animation;
} SellerState;
static SellerState seller_states[MAX_SELLERS];


static const char *termination_reasons[] = {
    "Profit target achieved!",
    "Too many frustrated customers",
    "Too many complaints",
    "Too many missing items",
     "......................"


};

static const char *customer_state_names[] = {
    "Entering",
    "Waiting",
    "Being served",
    "Happy",
    "Frustrated",
    "Refunding"
};

// Helper functions
static void draw_text(float x, float y, const char *text, void *font);
static void draw_circle(float cx, float cy, float radius, float r, float g, float b);
static void draw_fancy_seller(float x, float y, int state, float animation, int seller_num);
static void draw_fancy_customer(float x, float y, int state, float animation, const char* items);
static void draw_ready_to_sell_panel(void);
static void draw_inventory_grid(void);
static void draw_business_metrics(void);
static void draw_sellers_panel(void);
static void draw_termination_reason(void);
static void draw_customers(void);
static void update_seller_states(void);
static void update_customer_states(void);
static void attach_shared_memory(void);
static void connect_message_queue(void);
static void draw_zones_layout(void);

static void connect_message_queue(void) {
    int retries = 5;
    while (retries-- > 0) {
        msgid = msgget(MSG_QUEUE_KEY, 0666);
        if (msgid != -1) return;
        sleep(1);
    }
    fatal("msgget failed after multiple attempts - make sure bakery_sim is running");
}
////////////////////////////////////////////////////////////////////

static void  update_suppliers(void);
static void  draw_suppliers(void);
static void  draw_fancy_supplier(float x,float y,int st,float an);
static void get_basket_pos(int idx, float *out_x, float *out_y) {
    float x1=-0.98f, y1=0.72f, dx=0.21f, dy=0.16f;
    float sx = x1 + 0.03f, sy = y1 - 0.03f;
    int cols = 2;
    int row = idx / cols, col = idx % cols;
    float px = sx + col*dx;
    float py = sy - row*dy;
    *out_x = px + 0.11f/2.0f;  
    *out_y = py - 0.11f/2.0f;
}

// Labels
static const char *item_names[NUM_ITEMS] = {
    "Wheat", "Yeast", "Butter", "Milk", "Sugar", "Salt", "Sweet Items", "Cheese", "Salami"
};




// Basic drawing primitives
static void draw_text(float x, float y, const char *text, void *font) {
    glRasterPos2f(x,y);
    while(*text) glutBitmapCharacter(font, *text++);
}

static void draw_circle(float cx, float cy, float radius, float r, float g, float b) {
    glColor3f(r,g,b);
    glBegin(GL_POLYGON);
    for(int i=0;i<100;++i){
        float ang = 2.0f*M_PI*i/100;
        glVertex2f(cx+cosf(ang)*radius, cy+sinf(ang)*radius);
    }
    glEnd();
}
///////////////////////////////////////////////////Diana///////////////////////////////////////////////////////////////
static void update_suppliers(void) {
    int sup_count = inv->num_supply_chain;
    if (sup_count<1) sup_count=2;
    if (sup_count>MAX_SUPPLIERS) sup_count=MAX_SUPPLIERS;

    for(int i=0;i<sup_count;i++){
        supplier_anim[i] += 0.02f;

        switch(supplier_state[i]){
          case 0: 
            if(supplier_anim[i]>1.0f){
                supplier_anim[i]=0;
                supplier_state[i]=1; 
            }
            break;

          case 1: { 
            float tx = supplier_target[i][0];
            float ty = supplier_target[i][1];
            if (fabs(supplier_pos[i][0] - tx) > SUP_SPEED)
                 supplier_pos[i][0] += (tx > supplier_pos[i][0] ? SUP_SPEED : -SUP_SPEED);
            else supplier_pos[i][0] = tx;
            if (fabs(supplier_pos[i][1] - ty) > SUP_SPEED)
                 supplier_pos[i][1] += (ty > supplier_pos[i][1] ? SUP_SPEED : -SUP_SPEED);
            else supplier_pos[i][1] = ty;

            if (supplier_pos[i][0]==tx && supplier_pos[i][1]==ty){
                supplier_state[i]=2;
                supplier_anim[i]=0;
            }
            break;
          }

          case 2: 
          if(supplier_anim[i]>1.5f){
              supplier_box_idx[i] = (supplier_box_idx[i] + 1) % NUM_ITEMS;
              get_basket_pos(supplier_box_idx[i],
                             &supplier_target[i][0],
                             &supplier_target[i][1]);

              supplier_anim[i]=0;
              supplier_state[i]=3; 
          }
          break;

          case 3: { 
            float by = SUP_BASE_Y;
            float orig_x = SUP_LEFT_X + (i * (SUP_RIGHT_X-SUP_LEFT_X)/(sup_count-1));
            if (fabs(supplier_pos[i][0] - orig_x) > SUP_SPEED)
                 supplier_pos[i][0] += (orig_x > supplier_pos[i][0] ? SUP_SPEED : -SUP_SPEED);
            else supplier_pos[i][0] = orig_x;
            if (fabs(supplier_pos[i][1] - by) > SUP_SPEED)
                 supplier_pos[i][1] += (by > supplier_pos[i][1] ? SUP_SPEED : -SUP_SPEED);
            else {
                 supplier_pos[i][1] = by;
                 supplier_state[i]=0;
                 supplier_anim[i]=0;
            }
            break;
          }
        }
    }
}


static void draw_suppliers(void) {

    int sup_count = inv->num_supply_chain;
    if (sup_count < 1)             sup_count = 2;
    if (sup_count > MAX_SUPPLIERS) sup_count = MAX_SUPPLIERS;

    for(int i = 0; i < sup_count; i++){
        glPushMatrix();
        glTranslatef(supplier_pos[i][0], supplier_pos[i][1], 0);
        glScalef(SUPPLIER_SCALE, SUPPLIER_SCALE, 1.0f);
        draw_fancy_supplier(0.0f, 0.0f, supplier_state[i], supplier_anim[i]);
        glPopMatrix();
    }
}

//============================================================================
static void draw_fancy_supplier(float x, float y, int state, float anim) {
    draw_circle(x, y + 0.06f, 0.04f,  0.96f, 0.87f, 0.70f);

    glColor3f(0.0f, 0.0f, 0.0f);
    draw_circle(x - 0.015f, y + 0.065f, 0.005f, 0,0,0);
    draw_circle(x + 0.015f, y + 0.065f, 0.005f, 0,0,0);

    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);
      if(state == 3) {
        for(int i=0;i<=5;i++){
          float a = M_PI + (M_PI * i / 5.0f);
          glVertex2f(x + cosf(a)*0.02f, y + 0.045f + sinf(a)*0.005f);
        }
      } else {
        glVertex2f(x-0.01f, y+0.045f);
        glVertex2f(x+0.01f, y+0.045f);
      }
    glEnd();

    glColor3f(0.4f, 0.6f, 0.9f);  
    glBegin(GL_QUADS);
      glVertex2f(x-0.03f, y + 0.02f);
      glVertex2f(x+0.03f, y + 0.02f);
      glVertex2f(x+0.03f, y - 0.04f);
      glVertex2f(x-0.03f, y - 0.04f);
    glEnd();

    glColor3f(0.96f, 0.87f, 0.70f); 
    glBegin(GL_LINES);
      glVertex2f(x - 0.02f, y + 0.00f);
      glVertex2f(x - 0.06f, y - 0.02f);
      glVertex2f(x + 0.02f, y + 0.00f);
      glVertex2f(x + 0.10f, y - 0.02f);
    glEnd();

    draw_circle(x + 0.10f, y - 0.02f, 0.012f, 0.96f,0.87f,0.70f);

    glColor3f(0.7f, 0.5f, 0.3f);
    glBegin(GL_QUADS);
      glVertex2f(x+0.08f, y - 0.02f + 0.01f);
      glVertex2f(x+0.12f, y - 0.02f + 0.01f);
      glVertex2f(x+0.12f, y - 0.06f );
      glVertex2f(x+0.08f, y - 0.06f );
    glEnd();
    glColor3f(0.4f,0.3f,0.1f);
    glBegin(GL_LINE_LOOP);
      glVertex2f(x+0.08f, y - 0.02f + 0.01f);
      glVertex2f(x+0.12f, y - 0.02f + 0.01f);
      glVertex2f(x+0.12f, y - 0.06f );
      glVertex2f(x+0.08f, y - 0.06f );
    glEnd();

    glColor3f(0.3f,0.2f,0.1f);
    glBegin(GL_LINES);
      glVertex2f(x - 0.015f, y - 0.04f);
      glVertex2f(x - 0.015f, y - 0.10f);
      glVertex2f(x + 0.015f, y - 0.04f);
      glVertex2f(x + 0.015f, y - 0.10f);
    glEnd();

    glBegin(GL_QUADS);
      glVertex2f(x-0.025f, y - 0.10f);
      glVertex2f(x+0.005f, y - 0.10f);
      glVertex2f(x+0.005f, y - 0.12f);
      glVertex2f(x-0.025f, y - 0.12f);
      glVertex2f(x+0.005f, y - 0.10f);
      glVertex2f(x+0.035f, y - 0.10f);
      glVertex2f(x+0.035f, y - 0.12f);
      glVertex2f(x+0.005f, y - 0.12f);
    glEnd();
}





////////////////////////////////////////////////Diana///////////////////////////////////////////////////////////////

/////////////////////////////////////////////////MASA______________________________________________________________________________________

// Enhanced seller visualization
static void draw_fancy_seller(float x, float y, int state, float animation, int seller_num) {
    float hat_r = seller_num == 0 ? 0.8f : 0.2f;
    float hat_g = seller_num == 0 ? 0.2f : 0.5f;
    float hat_b = seller_num == 0 ? 0.2f : 0.8f;

    glColor3f(hat_r, hat_g, hat_b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x, y+0.1f);
    glVertex2f(x-0.05f, y+0.03f);
    glVertex2f(x+0.05f, y+0.03f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(x-0.05f, y+0.03f);
    glVertex2f(x+0.05f, y+0.03f);
    glVertex2f(x+0.04f, y);
    glVertex2f(x-0.04f, y);
    glEnd();

     
    glColor3f(0.96f, 0.87f, 0.7f);
    draw_circle(x, y-0.02f, 0.04f, 0.96f, 0.87f, 0.7f);

    glColor3f(0.0f, 0.0f, 0.0f);
    if(state == 1) { 
        draw_circle(x-0.015f, y-0.01f, 0.008f, 0.0f, 0.0f, 0.0f);
        draw_circle(x+0.015f, y-0.01f, 0.008f, 0.0f, 0.0f, 0.0f);
    } else { 
        glBegin(GL_LINES);
        glVertex2f(x-0.02f, y-0.01f);
        glVertex2f(x-0.01f, y-0.01f);
        glVertex2f(x+0.01f, y-0.01f);
        glVertex2f(x+0.02f, y-0.01f);
        glEnd();
    }

    
    if (state == 0) { 
        glBegin(GL_LINE_STRIP);
        for (int i = 0; i <= 5; i++) {
            float angle = M_PI + (M_PI * i / 5.0f);
            glVertex2f(x + cosf(angle)*0.02f, y - 0.03f + sinf(angle)*0.01f);
        }
        glEnd();
    } else if (state == 1) { 
        float open = fabs(sinf(animation * 5.0f)) * 0.01f;
        glBegin(GL_LINES);
        glVertex2f(x-0.015f, y-0.03f - open);
        glVertex2f(x+0.015f, y-0.03f - open);
        glEnd();
    } else { 
        glBegin(GL_LINE_STRIP);
        for (int i = 0; i <= 10; i++) {
            float angle = (M_PI * i / 10.0f);
            glVertex2f(x + cosf(angle)*0.02f, y - 0.03f + sinf(angle)*0.01f);
        }
        glEnd();
    }

  
    glColor3f(0.9f, 0.9f, 0.9f);
    glBegin(GL_QUADS);
    glVertex2f(x-0.04f, y-0.06f);
    glVertex2f(x+0.04f, y-0.06f);
    glVertex2f(x+0.04f, y-0.12f);
    glVertex2f(x-0.04f, y-0.12f);
    glEnd();

    
    glColor3f(0.8f, 0.2f, 0.2f);
    glBegin(GL_QUADS);
    glVertex2f(x-0.04f, y-0.08f);
    glVertex2f(x+0.04f, y-0.08f);
    glVertex2f(x+0.04f, y-0.12f);
    glVertex2f(x-0.04f, y-0.12f);
    glEnd();

    glColor3f(0.96f, 0.87f, 0.7f);
    if (state == 1) { 
        float arm_angle = sinf(animation * 5.0f) * 0.3f;
        glBegin(GL_LINES);
    
        glVertex2f(x-0.04f, y-0.08f);
        glVertex2f(x-0.08f - arm_angle*0.5f, y-0.06f + arm_angle);
        
        glVertex2f(x+0.04f, y-0.08f);
        glVertex2f(x+0.08f + arm_angle*0.5f, y-0.06f + arm_angle);
        glEnd();

        
        draw_circle(x-0.08f - arm_angle*0.5f, y-0.06f + arm_angle, 0.015f, 0.96f, 0.87f, 0.7f);
        draw_circle(x+0.08f + arm_angle*0.5f, y-0.06f + arm_angle, 0.015f, 0.96f, 0.87f, 0.7f);
    } else {
        glBegin(GL_LINES);
       
        glVertex2f(x-0.04f, y-0.08f);
        glVertex2f(x-0.08f, y-0.1f);
        
        glVertex2f(x+0.04f, y-0.08f);
        glVertex2f(x+0.08f, y-0.1f);
        glEnd();

        
        draw_circle(x-0.08f, y-0.1f, 0.015f, 0.96f, 0.87f, 0.7f);
        draw_circle(x+0.08f, y-0.1f, 0.015f, 0.96f, 0.87f, 0.7f);
    }

    
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
    glVertex2f(x-0.03f, y-0.13f);
    glVertex2f(x+0.03f, y-0.13f);
    glVertex2f(x+0.03f, y-0.15f);
    glVertex2f(x-0.03f, y-0.15f);
    glEnd();

    glColor3f(0.0f, 0.0f, 0.0f);
    char name[20];
    snprintf(name, sizeof(name), "Seller %d", seller_num+1);
    draw_text(x-0.025f, y-0.145f, name, GLUT_BITMAP_HELVETICA_10);
}

static void draw_fancy_customer(float x, float y, int state, float animation, const char* items) {
    const float scale = 0.7f;
    const float head_radius = 0.03f * scale;
    const float body_width = 0.06f * scale;
    const float body_height = 0.05f * scale;

    
    float head_r, head_g, head_b;
    if (state == CUSTOMER_REFUND_PROCESSING) {
        head_r = 0.8f; head_g = 0.4f; head_b = 0.8f;
    } else if (state == CUSTOMER_FRUSTRATED_EXIT) {
        head_r = 0.9f; head_g = 0.5f; head_b = 0.5f;
    } else {
        head_r = 0.96f; head_g = 0.87f; head_b = 0.7f;
    }

  
    float body_r, body_g, body_b;
    switch(state) {
        case CUSTOMER_HAPPY_EXIT:    body_r=0.4f; body_g=0.8f; body_b=0.4f; break;
        case CUSTOMER_REFUND_PROCESSING: body_r=0.7f; body_g=0.2f; body_b=0.7f; break;
        case CUSTOMER_ORDERING: body_r=1.0f; body_g=1.0f; body_b=0.0f; break;
        case CUSTOMER_FRUSTRATED_EXIT: body_r=0.9f; body_g=0.3f; body_b=0.3f; break;
        default: body_r=0.4f; body_g=0.4f; body_b=0.8f; break;
    }

    glColor3f(head_r, head_g, head_b);
    draw_circle(x, y, head_radius, head_r, head_g, head_b);

glColor3f(0.1f, 0.1f, 0.1f);


glBegin(GL_POINTS);
glVertex2f(x - head_radius/3, y + head_radius/4); 
glVertex2f(x + head_radius/3, y + head_radius/4); 
glEnd();


if (state == CUSTOMER_HAPPY_EXIT) {
   
    glBegin(GL_LINE_STRIP);
    for (float angle = 0.25f; angle < 0.75f; angle += 0.1f) {
        glVertex2f(x + cos(angle * M_PI) * head_radius/2,
                  y - head_radius/3 + sin(angle * M_PI) * head_radius/4);
    }
    glEnd();
}
else if (state == CUSTOMER_REFUND_PROCESSING || state == CUSTOMER_FRUSTRATED_EXIT) {
    
    glBegin(GL_LINES);
    
    glVertex2f(x - head_radius/3, y - head_radius/3);
    glVertex2f(x + head_radius/3, y - head_radius/3);
    
    glVertex2f(x - head_radius/2, y + head_radius/3);
    glVertex2f(x - head_radius/4, y + head_radius/2);
    glVertex2f(x + head_radius/4, y + head_radius/2);
    glVertex2f(x + head_radius/2, y + head_radius/3);
    glEnd();
}
else {
    
    glBegin(GL_LINES);
    glVertex2f(x - head_radius/3, y - head_radius/4);
    glVertex2f(x + head_radius/3, y - head_radius/4);
    glEnd();
}


glColor3f(body_r, body_g, body_b);
glBegin(GL_QUADS);
glVertex2f(x-body_width/2, y-head_radius);
glVertex2f(x+body_width/2, y-head_radius);
glVertex2f(x+body_width/2, y-head_radius-body_height);
glVertex2f(x-body_width/2, y-head_radius-body_height);
glEnd();


glColor3f(head_r, head_g, head_b);
if (state == CUSTOMER_WAITING) {

}
else {

}

    if (items && strlen(items) > 0) {
        int line_count = 1;
        const char *p = items;
        while (*p) if (*p++ == '\n') line_count++;

        float bubble_height = 0.05f + (line_count * 0.03f);
        float bubble_width = 0.25f;

        glColor3f(1.0f, 1.0f, 1.0f);
        glBegin(GL_POLYGON);
        glVertex2f(x-0.1f*scale, y+0.1f*scale);
        glVertex2f(x-0.1f*scale + bubble_width, y+0.1f*scale);
        glVertex2f(x-0.1f*scale + bubble_width, y+0.1f*scale + bubble_height);
        glVertex2f(x-0.1f*scale, y+0.1f*scale + bubble_height);
        glEnd();

        glColor3f(0.5f, 0.5f, 0.5f);
        glBegin(GL_LINE_LOOP);
        glVertex2f(x-0.1f*scale, y+0.1f*scale);
        glVertex2f(x-0.1f*scale + bubble_width, y+0.1f*scale);
        glVertex2f(x-0.1f*scale + bubble_width, y+0.1f*scale + bubble_height);
        glVertex2f(x-0.1f*scale, y+0.1f*scale + bubble_height);
        glEnd();

        glBegin(GL_TRIANGLES);
        glVertex2f(x-0.05f*scale, y+0.1f*scale);
        glVertex2f(x-0.08f*scale, y+0.07f*scale);
        glVertex2f(x-0.02f*scale, y+0.07f*scale);
        glEnd();

        glColor3f(0.0f, 0.0f, 0.0f);
        float text_y = y + 0.1f*scale + bubble_height - 0.02f;

        char *text = strdup(items);
        char *line = strtok(text, "\n");
        while (line) {
            char buffer[256];
            strncpy(buffer, line, sizeof(buffer));
            buffer[sizeof(buffer)-1] = '\0';

            int max_chars = 30;
            if (strlen(buffer) > max_chars) {
                int space_pos = max_chars;
                while (space_pos > 0 && buffer[space_pos] != ' ') space_pos--;
                if (space_pos > 0) {
                    buffer[space_pos] = '\0';
                    draw_text(x-0.09f*scale, text_y, buffer, GLUT_BITMAP_HELVETICA_10);
                    text_y -= 0.03f;
                    draw_text(x-0.09f*scale, text_y, buffer+space_pos+1, GLUT_BITMAP_HELVETICA_10);
                } else {
                    draw_text(x-0.09f*scale, text_y, buffer, GLUT_BITMAP_HELVETICA_10);
                }
            } else {
                draw_text(x-0.09f*scale, text_y, buffer, GLUT_BITMAP_HELVETICA_10);
            }

            text_y -= 0.03f;
            line = strtok(NULL, "\n");
        }
        free(text);
    }
}


static void draw_customers() {
    for (int i = 0; i < num_tracked_customers; i++) {
        char info[300];
        snprintf(info, sizeof(info), "Status: %s\nItems: %s\nWait: %ds",
                customer_state_names[customers[i].state],
                customers[i].items,
                customers[i].timeout);

        draw_fancy_customer(customers[i].x, customers[i].y,
                          customers[i].state, customers[i].animation, info);
    }
}

static void draw_zones_layout(void) {
    const int ZONE_COUNT = 6;
    const char* zone_names[] = {  
        "ENTRANCE", "ORDER", "WAITING", "SERVICE", "REFUND", "EXIT"
    };

    float zone_width = 2.0f / ZONE_COUNT;

    glColor3f(0.7f, 0.7f, 0.7f);
    glBegin(GL_LINES);
    for (int i = 0; i <= ZONE_COUNT; i++) {
        float x = -1.0f + i * zone_width;
        glVertex2f(x, -0.5f);
        glVertex2f(x, -0.7f);
    }
    glEnd();

    glColor3f(0.2f, 0.2f, 0.2f);
    for (int i = 0; i < ZONE_COUNT; i++) {
        float x = -1.0f + i * zone_width + zone_width/2;
        draw_text(x - strlen(zone_names[i])*0.01f, -0.55f,
                 zone_names[i], GLUT_BITMAP_HELVETICA_10);
    }

    glColor3f(0.3f, 0.3f, 0.8f);
    glBegin(GL_LINES);
    for (int i = 0; i < ZONE_COUNT-1; i++) {
        float x1 = -1.0f + (i+1) * zone_width - 0.1f;
        float x2 = x1 + 0.05f;
        glVertex2f(x1, -0.65f);
        glVertex2f(x2, -0.65f);
        glVertex2f(x2, -0.65f);
        glVertex2f(x2-0.03f, -0.62f);
        glVertex2f(x2, -0.65f);
        glVertex2f(x2-0.03f, -0.68f);
    }
    glEnd();
}

static void get_customer_position(int state, float* x, float* y, float animation, int queue_pos) {
    const float queue_spacing = 0.15f;
    const float vertical_offset = 0.05f;

    switch(state) {
        case CUSTOMER_ENTERING:
            *x = zones.enter_x;
            *y = zones.enter_y + queue_pos * vertical_offset;
            break;

        case CUSTOMER_ORDERING:
            *x = zones.request_x;
            *y = zones.request_y + queue_pos * vertical_offset;
            break;

        case CUSTOMER_WAITING:
            *x = zones.wait_x + (queue_pos % 5) * queue_spacing;
            *y = zones.wait_y - (queue_pos / 5) * vertical_offset;
            break;

        case CUSTOMER_BEING_SERVED:
            *x = zones.serve_x + (queue_pos % inv->num_sellers) * 0.2f;
            *y = zones.serve_y - (queue_pos / inv->num_sellers) * vertical_offset;
            break;

        case CUSTOMER_REFUND_PROCESSING:
            *x = zones.refund_x;
            *y = zones.refund_y + queue_pos * vertical_offset;
            break;

        case CUSTOMER_HAPPY_EXIT:
        case CUSTOMER_FRUSTRATED_EXIT:
            *x = zones.exit_x;
            *y = zones.exit_y + queue_pos * vertical_offset;
            break;
    }
}



static void draw_business_metrics(void) {
    float start_x = -0.55f;
    float start_y = 0.2f;
    float width = 0.5f;
    float height = 0.4f;

    glColor3f(0.95f, 0.95f, 0.97f);
    glBegin(GL_QUADS);
        glVertex2f(start_x, start_y);
        glVertex2f(start_x + width, start_y);
        glVertex2f(start_x + width, start_y - height);
        glVertex2f(start_x, start_y - height);
    glEnd();

    glColor3f(0.3f, 0.4f, 0.6f);
    glBegin(GL_QUADS);
        glVertex2f(start_x, start_y);
        glVertex2f(start_x + width, start_y);
        glVertex2f(start_x + width, start_y - 0.07f);
        glVertex2f(start_x, start_y - 0.07f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    draw_text(start_x + width/2 - 0.07f, start_y - 0.05f, "Business Metrics", GLUT_BITMAP_HELVETICA_18);

    float profit_ratio = (float)inv->profit / (float)inv->target_profit;
    if (profit_ratio > 1.0f) profit_ratio = 1.0f;

    glColor3f(0.2f, 0.2f, 0.2f);
    draw_text(start_x + 0.05f, start_y - 0.12f, "Profit", GLUT_BITMAP_HELVETICA_12);

    glColor3f(0.85f, 0.85f, 0.85f);
    glBegin(GL_QUADS);
        glVertex2f(start_x + 0.15f, start_y - 0.13f);
        glVertex2f(start_x + width - 0.05f, start_y - 0.13f);
        glVertex2f(start_x + width - 0.05f, start_y - 0.11f);
        glVertex2f(start_x + 0.15f, start_y - 0.11f);
    glEnd();

    if (profit_ratio < 0.3f) {
        glColor3f(1.0f, profit_ratio/0.3f, 0.0f);
    } else {
        glColor3f(1.0f - (profit_ratio - 0.3f)/0.7f, 1.0f, 0.0f);
    }

    float bar_width = (width - 0.2f) * profit_ratio;
    glBegin(GL_QUADS);
        glVertex2f(start_x + 0.15f, start_y - 0.13f);
        glVertex2f(start_x + 0.15f + bar_width, start_y - 0.13f);
        glVertex2f(start_x + 0.15f + bar_width, start_y - 0.11f);
        glVertex2f(start_x + 0.15f, start_y - 0.11f);
    glEnd();

    char profit_text[64];
    sprintf(profit_text, "%d / %d", inv->profit, inv->target_profit);
    glColor3f(0.2f, 0.2f, 0.2f);
    draw_text(start_x + width - 0.13f, start_y - 0.12f, profit_text, GLUT_BITMAP_HELVETICA_12);

    
    glColor3f(0.2f, 0.2f, 0.2f);
    draw_text(start_x + 0.05f, start_y - 0.22f, "Complaints", GLUT_BITMAP_HELVETICA_12);

    float circle_x = start_x + 0.15f;
    for (int i = 0; i < inv->complaints && i < 10; i++) {
        glColor3f(1.0f, 0.3f, 0.3f);
        draw_circle(circle_x+ 0.05f, start_y - 0.22f, 0.015f, 1.0f, 0.3f, 0.3f);
        circle_x += 0.04f;
    }

    char complaint_text[32];
    sprintf(complaint_text, "%d / %d", inv->complaints, inv->max_complaints);
    glColor3f(0.2f, 0.2f, 0.2f);
    draw_text(start_x + width - 0.13f, start_y - 0.22f, complaint_text, GLUT_BITMAP_HELVETICA_12);

    glColor3f(0.2f, 0.2f, 0.2f);
    draw_text(start_x + 0.05f, start_y - 0.32f, "Frustrated Customers", GLUT_BITMAP_HELVETICA_12);

    float clock_x = start_x + 0.05f;
    int waiting_to_draw = inv->frustrated_waiting > 5 ? 5 : inv->frustrated_waiting;

    for (int i = 0; i < waiting_to_draw; i++) {
        float base_y = start_y - 0.39f;

        glColor3f(0.9f, 0.9f, 0.5f);
        draw_circle(clock_x, base_y, 0.02f, 0.9f, 0.9f, 0.5f);

        glColor3f(0.3f, 0.3f, 0.3f);
        glBegin(GL_LINE_LOOP);
        for (int j = 0; j < 12; j++) {
            float angle = 2.0f * M_PI * j / 12.0f;
            glVertex2f(clock_x + cosf(angle)*0.02f, base_y + sinf(angle)*0.02f);
        }
        glEnd();

        glBegin(GL_LINES);
        glVertex2f(clock_x, base_y);
        glVertex2f(clock_x + cosf(M_PI/4)*0.015f, base_y + sinf(M_PI/4)*0.015f);
        glEnd();

        glBegin(GL_LINES);
        glVertex2f(clock_x, base_y);
        glVertex2f(clock_x + cosf(M_PI/2)*0.018f, base_y + sinf(M_PI/2)*0.018f);
        glEnd();

        clock_x += 0.05f;
    }

    float face_x = clock_x;
    int complaint_to_draw = inv->frustrated_customers > 5 ? 5 : inv->frustrated_customers;

    for (int i = 0; i < complaint_to_draw; i++) {
        float base_y = start_y - 0.39f;

        glColor3f(1.0f, 0.8f, 0.8f);
        draw_circle(face_x, base_y, 0.02f, 1.0f, 0.8f, 0.8f);

        glColor3f(0.2f, 0.2f, 0.2f);
        draw_circle(face_x - 0.007f, base_y + 0.01f, 0.003f, 0.2f, 0.2f, 0.2f);
        draw_circle(face_x + 0.007f, base_y + 0.01f, 0.003f, 0.2f, 0.2f, 0.2f);

        glBegin(GL_LINE_STRIP);
        for (int j = 0; j <= 10; j++) {
            float angle = M_PI - (M_PI * j / 10.0f);
            float x = face_x + cosf(angle) * 0.01f;
            float y = base_y - 0.012f + sinf(angle) * 0.006f;
            glVertex2f(x, y);
        }
        glEnd();

        face_x += 0.05f;
    }

    char frust_text[100];
    sprintf(frust_text, "%d (Wait) + %d (Complaints) = %d / %d",
            inv->frustrated_waiting, inv->frustrated_customers,
            (inv->frustrated_waiting + inv->frustrated_customers),
            inv->max_frustrated_customers);
    glColor3f(0.2f, 0.2f, 0.2f);
    draw_text(start_x + 0.15f, start_y - 0.37f, frust_text, GLUT_BITMAP_HELVETICA_12);
}

static void draw_sellers_panel(void) {
    float start_x = -0.55f;
    float start_y = 0.72f;
    float width = 0.3f;
    float height = 0.4f;

    glColor3f(0.95f, 0.95f, 0.97f);
    glBegin(GL_QUADS);
        glVertex2f(start_x, start_y);
        glVertex2f(start_x + width, start_y);
        glVertex2f(start_x + width, start_y - height);
        glVertex2f(start_x, start_y - height);
    glEnd();

    glColor3f(0.3f, 0.4f, 0.6f);
    glBegin(GL_QUADS);
        glVertex2f(start_x, start_y);
        glVertex2f(start_x + width, start_y);
        glVertex2f(start_x + width, start_y - 0.08f);
        glVertex2f(start_x, start_y - 0.08f);
    glEnd();

    glColor3f(1.0f, 1.0f, 1.0f);
    draw_text(start_x + width/2 - 0.04f, start_y - 0.06f,
             "Sellers", GLUT_BITMAP_HELVETICA_12);

    float seller_x = start_x + 0.05f;
    float seller_y = start_y - 0.15f;
    float spacing = width / (inv->num_sellers + 1); 

    glPushMatrix();
    glScalef(0.7f, 0.7f, 1.0f);

    for (int i = 0; i < inv->num_sellers; i++) {
        float scaled_x = (seller_x + i * spacing) / 0.7f;
        float scaled_y = seller_y / 0.7f;

        draw_fancy_seller(scaled_x, scaled_y, seller_states[i].state,
                         seller_states[i].animation, i);

        const char* status_text;
        switch(seller_states[i].state) {
            case 0: status_text = ""; break;
            case 1: status_text = ""; break;
            case 2: status_text = ""; break;
            case 3: status_text = ""; break;
            default: status_text = ""; break;
        }

        draw_text((scaled_x + 0.25f) * 1.7f, (seller_y +0.2f) * 0.7f,
                 status_text, GLUT_BITMAP_HELVETICA_10);
        draw_text((scaled_x + 0.25f) * 1.7f, (seller_y +0.2f) * 0.7f,
                 seller_states[i].status, GLUT_BITMAP_HELVETICA_10);
    }

    glPopMatrix(); 
}

static void draw_termination_reason(void) {
    if(inv->profit >= inv->target_profit) {
        draw_text(-0.95f, -0.95f, termination_reasons[0], GLUT_BITMAP_HELVETICA_12);
    } else if(inv->frustrated_customers + inv->frustrated_waiting >= inv->max_frustrated_customers) {
        draw_text(-0.95f, -0.95f, termination_reasons[1], GLUT_BITMAP_HELVETICA_12);
    } else if(inv->complaints >= inv->max_complaints) {
        draw_text(-0.95f, -0.95f, termination_reasons[2], GLUT_BITMAP_HELVETICA_12);
    } else if(inv->missing_requests >= inv->max_missing_item_requests) {
        draw_text(-0.95f, -0.95f, termination_reasons[3], GLUT_BITMAP_HELVETICA_12);
    } else {
        draw_text(-0.95f, -0.95f, termination_reasons[4], GLUT_BITMAP_HELVETICA_12);
    }

    char frust_text[100];
    sprintf(frust_text, "Frustrated: %d (Complaints) + %d (Waiting) = %d",
            inv->frustrated_customers, inv->frustrated_waiting,
            inv->frustrated_customers + inv->frustrated_waiting);
    glColor3f(0.8f, 0.2f, 0.2f);
    draw_text(-0.95f, -0.90f, frust_text, GLUT_BITMAP_HELVETICA_12);
}



static void update_seller_states(void) {
    SellerStateMessage msg;
    while (msgrcv(msgid, &msg, sizeof(SellerStateMessage) - sizeof(long), MSG_TYPE_SELLER_STATE, IPC_NOWAIT) > 0) {
        int found = 0;
        for (int i = 0; i < MAX_SELLERS; i++) {  
            if (seller_states[i].pid == 0 || seller_states[i].pid == msg.seller_pid) {
                seller_states[i].pid = msg.seller_pid;
                seller_states[i].state = msg.state;
                strncpy(seller_states[i].status, msg.status, sizeof(seller_states[i].status));
                seller_states[i].animation = 0;  
                found = 1;
                break;
            }
        }

        if (!found) {
            fprintf(stderr, "Warning: Could not track seller %d (max sellers reached)\n", msg.seller_pid);
        }
    }

    for (int i = 0; i < MAX_SELLERS; i++) {
        if (seller_states[i].pid != 0) {  
            seller_states[i].animation += 0.1f;
        }
    }
}


static void update_customer_states() {
    CustomerStateMessage msg;
    while (msgrcv(msgid, &msg, sizeof(CustomerStateMessage) - sizeof(long), MSG_TYPE_CUSTOMER_STATE, IPC_NOWAIT) > 0) {
        int found = 0;
        for (int i = 0; i < num_tracked_customers; i++) {
            if (customers[i].pid == msg.customer_pid) {
                if (customers[i].state != msg.state) {
                    customers[i].prev_state = customers[i].state;
                    customers[i].state = msg.state;
                    customers[i].state_time = 0;
                    customers[i].queue_position = 0; // Reset position on state change
                }
                strncpy(customers[i].items, msg.items, sizeof(customers[i].items));
                customers[i].last_update = time(NULL);
                customers[i].timeout = msg.timeout;
                found = 1;
                break;
            }
        }

        if (!found && num_tracked_customers < MAX_CUSTOMERS) {
            customers[num_tracked_customers].pid = msg.customer_pid;
            customers[num_tracked_customers].state = msg.state;
            customers[num_tracked_customers].prev_state = -1;
            strncpy(customers[num_tracked_customers].items, msg.items, sizeof(customers[0].items));
            customers[num_tracked_customers].queue_position = 0;
            customers[num_tracked_customers].last_update = time(NULL);
            customers[num_tracked_customers].timeout = msg.timeout;
            customers[num_tracked_customers].state_time = 0;
            num_tracked_customers++;
        }
    }

    // Update queue positions for each state
    for (int state = CUSTOMER_ENTERING; state <= CUSTOMER_FRUSTRATED_EXIT; state++) {
        int queue_pos = 0;
        for (int i = 0; i < num_tracked_customers; i++) {
            if (customers[i].state == state) {
                customers[i].queue_position = queue_pos++;
            }
        }
    }

    // Update positions and animations
    for (int i = 0; i < num_tracked_customers; i++) {
        customers[i].animation += 0.1f;
        customers[i].state_time += 1;

        get_customer_position(customers[i].state, &customers[i].x, &customers[i].y,
                            customers[i].animation, customers[i].queue_position);

        if ((customers[i].x > 1.2f || customers[i].x < -1.2f) ||
            (time(NULL) - customers[i].last_update > 10)) {
            memmove(&customers[i], &customers[i+1],
                   (num_tracked_customers - i - 1) * sizeof(CustomerTracking));
            num_tracked_customers--;
            i--;
        }
    }
}



///////////////////////////////////////////////////MASA____________________________________________________________________________________





// Inventory helpers
static int *get_item_quantity(int i) {
    switch(i){
        case 0: return &inv->wheat;
        case 1: return &inv->yeast;
        case 2: return &inv->butter;
        case 3: return &inv->milk;
        case 4: return &inv->sugar;
        case 5: return &inv->salt;
        case 6: return &inv->sweet_items;
        case 7: return &inv->cheese;
        case 8: return &inv->salami;
        default: return NULL;
    }
}


static void draw_inventory_basket(const char *label,int quantity,float x,float y) {
    float w=0.11f,h=0.11f;
    float barMax = w*0.85f;

    // basket
    glColor3f(0.82f,0.64f,0.35f);
    glBegin(GL_QUADS);
        glVertex2f(x,     y);
        glVertex2f(x+w,   y);
        glVertex2f(x+w,   y-h);
        glVertex2f(x,     y-h);
    glEnd();

    float fill = fminf(quantity/10.0f,1.0f);
    float bw   = barMax*fill;

    if(quantity<=0)      glColor3f(1.0f,0.0f,0.0f);
    else if(quantity<=2) glColor3f(1.0f,0.3f,0.3f);
    else if(quantity<=5) glColor3f(1.0f,1.0f,0.4f);
    else                 glColor3f(0.6f,1.0f,0.6f);

    float bx = x+(w-barMax)/2;
    float by = y-h*0.4f;
    glBegin(GL_QUADS);
        glVertex2f(bx,     by);
        glVertex2f(bx+bw,  by);
        glVertex2f(bx+bw,  by-0.01f);
        glVertex2f(bx,     by-0.01f);
    glEnd();

    glColor3f(0.08f,0.08f,0.08f);
    draw_text(x+w/2-strlen(label)*0.005f, y-h*0.37f, label, GLUT_BITMAP_HELVETICA_12);

    char buf[32]; sprintf(buf, "%d units", quantity);
    draw_text(x+w/2-strlen(buf)*0.004f, y-h-0.00005f, buf, GLUT_BITMAP_HELVETICA_12);
}

static void draw_inventory_grid(void) {
    float x1=-0.98f,y1=0.72f;
    float x2=-0.60f,y2=-0.10f;

    glColor3f(0.9f,0.85f,0.80f);
    glBegin(GL_QUADS);
        glVertex2f(x1,y1); glVertex2f(x2,y1); glVertex2f(x2,y2); glVertex2f(x1,y2);
    glEnd();

    glColor3f(0.4f,0.2f,0.05f);
    glBegin(GL_QUADS);
        glVertex2f(x1,y1+0.07f); glVertex2f(x2,y1+0.07f);
        glVertex2f(x2,y1);       glVertex2f(x1,y1);
    glEnd();

    glColor3f(1,1,1);
    draw_text((x1+x2)/2- strlen("Inventory")*0.007f/2, y1+0.008f,
              "Inventory", GLUT_BITMAP_HELVETICA_18);

    float sx=x1+0.03f, sy=y1-0.03f; // start
    float dx=0.21f,    dy=0.16f;
    int   cols=2;
    for(int i=0;i<NUM_ITEMS;++i){
        int row=i/cols, col=i%cols;
        float px=sx+col*dx, py=sy-row*dy;
        draw_inventory_basket(item_names[i], *get_item_quantity(i), px, py);
    }
}

static void draw_ready_to_sell_panel(void) {
    const char* labels[] = { "Cakes", "Sweets", "Sandwiches", "Patisseries","Bread" };

    static const char* sub1[] = {"Vanilla","Chocolate","Strawberry","Bluebury"};
    static const char* sub2[] = {"Cookie","Donut","Croissant","Cupcake"};
    static const char* sub3[] = {
      "Salami (White)","Salami (Brown)",
      "Cheese (White)","Cheese (Brown)",
      "Both (White)","Both (Brown)"
    };
    static const char* sub4[] = {"Sweet Patisseries","Savory Patisseries"};
    static const char* sub5[] = {"White Bread","Brown Bread"};

    const int section_counts[] = {4,4,6,2,2};
    const char** sub_labels[] = {sub1,sub2,sub3,sub4,sub5};

    int vals1[] = {
        inv->total_vanilla_cakes_ready_to_sell, inv->total_chocolate_cakes_ready_to_sell,
        inv->total_strawberry_cakes_ready_to_sell, inv->total_blueburry_cakes_ready_to_sell
      };
      int vals2[] = {
        inv->total_cookie_sweets_ready_to_sell, inv->total_donut_sweets_ready_to_sell,
        inv->total_croissant_sweets_ready_to_sell, inv->total_cupcake_sweets_ready_to_sell
      };
      int vals3[] = {
        inv->sandwich_salami_white_count, inv->sandwich_salami_brown_count,
        inv->sandwich_cheese_white_count, inv->sandwich_cheese_brown_count,
        inv->sandwich_both_white_count,   inv->sandwich_both_brown_count
      };
      int vals4[] = {
        inv->total_sweet_patisseries_ready_to_sell, inv->total_savory_patisseries_ready_to_sell
      };
      int vals5[] = {
        inv->bread_white_ready, inv->bread_brown_ready
      };
      const int* sub_values[] = {vals1,vals2,vals3,vals4,vals5};
  
        float start_x=0.68f, start_y=0.75f, y_gap=0.16f, x_gap=0.09f, radius=0.025f;
    draw_text(0.70f, start_y+0.15f, "Ready to Sell", GLUT_BITMAP_HELVETICA_18);

    for(int sec=0; sec<5; ++sec){
        float y = start_y - sec*y_gap;
        glColor3f(0.4f,0.2f,0.05f);
        glBegin(GL_QUADS);
          glVertex2f(start_x-0.05f, y-0.01f);
          glVertex2f(0.98f,        y-0.01f);
          glVertex2f(0.98f,        y+0.01f);
          glVertex2f(start_x-0.05f, y+0.01f);
        glEnd();

        draw_text(start_x-0.09f, y+0.045f,
                  labels[sec], GLUT_BITMAP_HELVETICA_12);

        for(int i=0;i<section_counts[sec];++i){
            float cx = start_x + i*x_gap;
            float cy = y        + 0.05f;
            const char* name = sub_labels[sec][i];
            int val = sub_values[sec][i];

            if(sec==0){
                if(!strcmp(name,"Vanilla"))glColor3f(1,0.87f,0.68f);
                else if(!strcmp(name,"Chocolate"))glColor3f(0.4f,0.2f,0.1f);
                else if(!strcmp(name,"Strawberry"))glColor3f(1,0.6f,0.7f);
                else glColor3f(0.3f,0.4f,1);
            }
            else if(sec==1){
                if(!strcmp(name,"Cookie"))    glColor3f(0.9f,0.7f,0.5f);
                else if(!strcmp(name,"Donut"))glColor3f(1,0.4f,0.4f);
                else if(!strcmp(name,"Croissant"))glColor3f(1,0.9f,0.5f);
                else glColor3f(1,0.6f,0.8f);
            }
            else if(sec==2){
                if(strstr(name,"Salami"))glColor3f(1,0.3f,0.3f);
                else if(strstr(name,"Cheese"))glColor3f(0.6f,1,0.6f);
                else glColor3f(0.6f,0.9f,0.6f);
            }
            else if(sec==3){
                if(strstr(name,"Sweet"))glColor3f(1,0.8f,0.3f);
                else glColor3f(0.6f,0.9f,0.4f);
            }
            else {
                if(!strcmp(name,"White Bread"))glColor3f(1,0.95f,0.8f);
                else glColor3f(0.6f,0.4f,0.2f);
            }

            glBegin(GL_POLYGON);
            for(int j=0;j<100;++j){
                float a=2*M_PI*j/100;
                glVertex2f(cx+cosf(a)*radius, cy+sinf(a)*radius);
            }
            glEnd();

            glColor3f(0.05f,0.05f,0.05f);
            draw_text(cx - strlen(name)*0.005f, cy+0.03f, name, GLUT_BITMAP_HELVETICA_10);
            char buf[32]; sprintf(buf,"%d units",val);
            draw_text(cx - strlen(buf)*0.004f, cy-0.035f, buf, GLUT_BITMAP_HELVETICA_10);
        }
    }
}









static void timer_cb(int value) {
    blink_flag = !blink_flag;
    arm_angle += 0.3f;
    if (arm_angle > 2 * 3.14159f) arm_angle = 0;

    glutPostRedisplay();
    glutTimerFunc(1000 / 60, timer_cb, 0);  
}


static void attach_shared_memory(void) {
    int shm_id = shmget(SHM_KEY, sizeof(Inventory), 0666);
    if (shm_id < 0) fatal("shmget failed – make sure simulator is running first");
    inv = (Inventory *)shmat(shm_id, NULL, 0);
    if (inv == (void *)-1) fatal("shmat failed");
}

static void fatal(const char *ctx){
    fprintf(stderr, "%s: %s\n", ctx, strerror(errno));
    exit(EXIT_FAILURE);
}
const char* get_team_name(int team_id) {
    switch (team_id) {
        case 1: return "Paste";
        case 2: return "Cake";
        case 3: return "Sandwich";
        case 4: return "Sweet";
        case 5: return "Sweet Pat";
        case 6: return "Savory Pat";
        default: return "Unknown";
    }
}

static void draw_chef_with_status(float x, float y, int team_id, int paused, int blink) {
    float r, g, b;

    switch (team_id) {
        case 1: r = 0.8f; g = 0.2f; b = 0.2f; break;  // Paste
        case 2: r = 1.0f; g = 0.6f; b = 0.0f; break;  // Cake
        case 3: r = 0.2f; g = 0.6f; b = 0.8f; break;  // Sandwich
        case 4: r = 0.8f; g = 0.4f; b = 0.8f; break;  // Sweet
        case 5: r = 1.0f; g = 0.2f; b = 0.6f; break;  // Sweet Pat
        case 6: r = 0.6f; g = 0.4f; b = 0.2f; break;  // Savory Pat
        default: r = g = b = 0.5f; break;
    }

    if (paused) {
        r *= 0.4f;
        g *= 0.4f;
        b *= 0.4f;
    }

    draw_circle(x, y - 0.045f, 0.03f, 1.0f, 0.9f, 0.7f);

    const char* team_name = get_team_name(team_id);
    glColor3f(1.0f, 1.0f, 1.0f);  
    draw_text(x - 0.029f, y - 0.036f, team_name, GLUT_BITMAP_HELVETICA_12);
    glColor3f(0.1f, 0.1f, 0.1f);  
    draw_text(x - 0.028f, y - 0.037f, team_name, GLUT_BITMAP_HELVETICA_12);

    draw_circle(x, y, 0.02f, 1.0f, 0.9f, 0.7f);

    draw_circle(x - 0.007f, y + 0.005f, 0.0025f, 0.0f, 0.0f, 0.0f);
    draw_circle(x + 0.007f, y + 0.005f, 0.0025f, 0.0f, 0.0f, 0.0f);

    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINE_STRIP);
    float angle_start = paused ? -3.14f / 8 : -3.14f / 4;
    float angle_end   = paused ?  3.14f / 8 :  3.14f / 4;
    float offset      = paused ? -0.002f : -0.006f;
    for (float angle = angle_start; angle <= angle_end; angle += 0.1f) {
        glVertex2f(x + 0.01f * cosf(angle), y + offset + 0.007f * sinf(angle));
    }
    glEnd();

    draw_circle(x, y + 0.027f, 0.015f, r, g, b);
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
        glVertex2f(x - 0.015f, y + 0.027f);
        glVertex2f(x + 0.015f, y + 0.027f);
        glVertex2f(x + 0.01f, y + 0.07f);
        glVertex2f(x - 0.01f, y + 0.07f);
    glEnd();

    float arm_len = 0.035f;
    float angleL = paused ? 3.14f / 6 : sinf(arm_angle) * 0.6f;
    float angleR = paused ? -3.14f / 6 : -sinf(arm_angle) * 0.6f;

    glColor3f(0.2f, 0.2f, 0.2f);

    glBegin(GL_LINES);
        glVertex2f(x - 0.015f, y - 0.045f);
        glVertex2f(x - 0.015f + arm_len * cosf(angleL), y - 0.045f + arm_len * sinf(angleL));
    glEnd();

    float hand_x = x + 0.015f + arm_len * cosf(angleR);
    float hand_y = y - 0.045f + arm_len * sinf(angleR);
    glBegin(GL_LINES);
        glVertex2f(x + 0.015f, y - 0.045f);
        glVertex2f(hand_x, hand_y);
    glEnd();

    if (!paused) {
        glColor3f(0.6f, 0.6f, 0.6f);
        draw_circle(hand_x, hand_y, 0.012f, 0.6f, 0.6f, 0.6f);

        glBegin(GL_POLYGON);
            glVertex2f(hand_x - 0.01f, hand_y + 0.006f);
            glVertex2f(hand_x + 0.01f, hand_y + 0.006f);
            glVertex2f(hand_x + 0.007f, hand_y + 0.014f);
            glVertex2f(hand_x - 0.007f, hand_y + 0.014f);
        glEnd();
    }

    if (paused && blink) {
        draw_circle(x, y + 0.09f, 0.008f, 1.0f, 0.0f, 0.0f);
    }

    if (paused) {
        glColor3f(1.0f, 0.0f, 0.0f);
        draw_text(x - 0.025f, y - 0.09f, "Paused", GLUT_BITMAP_HELVETICA_10);
    }
}



void draw_ovens() {
    if (!inv) return;
    float startX = 0.65f;  
    float startY = -0.1f;    
    float width = 0.08f;
    float height = 0.08f;
    float spacing = 0.1f;
    

    for (int i = 0; i < OVEN_COUNT; ++i) {
        float x = startX + i * spacing;
        float y = startY;

        glColor3f(0.0f, 0.0f, 0.0f);
        glBegin(GL_LINE_LOOP);
            glVertex2f(x, y);
            glVertex2f(x + width, y);
            glVertex2f(x + width, y + height);
            glVertex2f(x, y + height);
        glEnd();

        if (inv->ovens[i] == 1)
            glColor3f(0.9f, 0.3f, 0.2f);  
        else
            glColor3f(0.4f, 0.9f, 0.4f);  

        glBegin(GL_QUADS);
            glVertex2f(x, y);
            glVertex2f(x + width, y);
            glVertex2f(x + width, y + height);
            glVertex2f(x, y + height);
        glEnd();

        // Label
        char label[16];
        snprintf(label, sizeof(label), "Oven %d", i + 1);
        glColor3f(0.1f, 0.1f, 0.1f);
        draw_text(x + 0.005f, y - 0.03f, label, GLUT_BITMAP_HELVETICA_10);
    }
}


static void draw_baker(float x, float y, int team_id, int paused, int baker_index)
{
    // If delivering, move right toward "Ready to Sell"
    if (inv->baker_is_delivering[baker_index]) {
        x = 0.8f;
        y = 0.6f - baker_index * 0.2f;
    } else {
        // If using an oven, stand near the oven
        for (int i = 0; i < OVEN_COUNT; ++i) {
            if (inv->oven_in_use_by[i] == team_id) {
                x = 0.63f + i * 0.1f;
                y = -0.02f;
                break;
            }
        }
    }

    float r, g, b;
    switch (team_id) {
        case 1: r = 0.8f; g = 0.6f; b = 0.2f; break;
        case 2: r = 0.6f; g = 0.3f; b = 0.8f; break;
        case 3: r = 0.3f; g = 0.7f; b = 0.3f; break;
        default: r = g = b = 0.5f; break;
    }

    if (paused) {
        r *= 0.4f; g *= 0.4f; b *= 0.4f;
    }

    draw_circle(x, y - 0.045f, 0.03f, 1.0f, 0.9f, 0.7f);
    draw_circle(x, y, 0.02f, 1.0f, 0.9f, 0.7f);
    draw_circle(x - 0.007f, y + 0.005f, 0.0025f, 0.0f, 0.0f, 0.0f);
    draw_circle(x + 0.007f, y + 0.005f, 0.0025f, 0.0f, 0.0f, 0.0f);

    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_LINE_STRIP);
    for (float angle = -3.14f / 4; angle <= 3.14f / 4; angle += 0.1f)
        glVertex2f(x + 0.01f * cosf(angle), y - 0.005f + 0.007f * sinf(angle));
    glEnd();

    draw_circle(x, y + 0.028f, 0.016f, r, g, b);
    glColor3f(r, g, b);
    glBegin(GL_POLYGON);
        glVertex2f(x - 0.018f, y + 0.028f);
        glVertex2f(x + 0.018f, y + 0.028f);
        glVertex2f(x + 0.014f, y + 0.058f);
        glVertex2f(x - 0.014f, y + 0.058f);
    glEnd();

    glColor3f(0.2f, 0.2f, 0.2f);
    float arm_len = 0.035f;
    glBegin(GL_LINES);
        glVertex2f(x - 0.015f, y - 0.045f);
        glVertex2f(x - 0.015f - arm_len, y - 0.045f);
    glEnd();

    float angle = paused ? 0.0f : sinf(arm_angle) * 0.3f;
    float rx = x + 0.015f + arm_len * cosf(angle);
    float ry = y - 0.045f + arm_len * sinf(angle);
    glBegin(GL_LINES);
        glVertex2f(x + 0.015f, y - 0.045f);
        glVertex2f(rx, ry);
    glEnd();

    if (!paused) {
        glColor3f(0.7f, 0.5f, 0.2f);
        glBegin(GL_POLYGON);
            glVertex2f(rx - 0.01f, ry - 0.005f);
            glVertex2f(rx + 0.01f, ry - 0.005f);
            glVertex2f(rx + 0.01f, ry + 0.005f);
            glVertex2f(rx - 0.01f, ry + 0.005f);
        glEnd();
    }

    const char *label;
    switch (team_id) {
        case 1: label = "Cake & Sweet"; break;
        case 2: label = "Patisserie"; break;
        case 3: label = "Bread"; break;
        default: label = "Unknown";
    }
    glColor3f(0.1f, 0.1f, 0.1f);
    draw_text(x - 0.035f, y - 0.08f, label, GLUT_BITMAP_HELVETICA_10);

    if (paused) {
        glColor3f(1.0f, 0.0f, 0.0f);
        draw_text(x - 0.025f, y - 0.095f, "Paused", GLUT_BITMAP_HELVETICA_10);
        draw_circle(x, y + 0.09f, 0.008f, 1.0f, 0.0f, 0.0f); // Red dot above head
    }
}
static void update_sandwich_movement() {
    
    if (!inv) return;

    int current_total = inv->sandwich_salami_white_count + inv->sandwich_salami_brown_count +
                        inv->sandwich_cheese_white_count + inv->sandwich_cheese_brown_count +
                        inv->sandwich_both_white_count + inv->sandwich_both_brown_count;

    int prev_total = prev_salami_white + prev_salami_brown +
                     prev_cheese_white + prev_cheese_brown +
                     prev_both_white + prev_both_brown;

    // If any sandwich count increased, trigger the chef to move
    if (current_total > prev_total) {
        sandwich_moving[0] = 1;

    }
    // Update previous values
    prev_salami_white = inv->sandwich_salami_white_count;
    prev_salami_brown = inv->sandwich_salami_brown_count;
    prev_cheese_white = inv->sandwich_cheese_white_count;
    prev_cheese_brown = inv->sandwich_cheese_brown_count;
    prev_both_white   = inv->sandwich_both_white_count;
    prev_both_brown   = inv->sandwich_both_brown_count;
    
    // Move the chef if flagged
    if (sandwich_moving[0]) {
        sandwich_chef_x[0] += 0.003f;

        if (sandwich_chef_x[0] >= 0.7f) {
            sandwich_moving[0] = 0;
            sandwich_chef_x[0] = 0.15f + 2 * 0.17f;  // Reset X
        }
    }
}


static int sandwich_initialized[MAX_CHEFS] = {0};


static void draw_chefs_grid() {
    if (!inv) return;
    frame_counter++;

    float startX = 0.15f, startY = 0.75f;
    float dx = 0.17f, dy = 0.18f;
    int row = 0, col = 0;

    float sandwich_start_x = 0.68f;
    float sandwich_y = 0.48f;
    float sandwich_x_gap = 0.09f;

    // Trigger movement from SHM only after frame 1
    for (int i = 0; i < MAX_CHEFS; i++) {
        if (frame_counter > 1 &&
            inv->chef_team_ids[i] == 3 &&
            inv->sandwich_chef_is_delivering[i] &&
            !sandwich_moving[i] &&
            inv->paused_team_ids[i] == 0)
        {
            sandwich_moving[i] = 1;
        }
    }

    for (int i = 0; i < MAX_CHEFS; i++) {
        int team = inv->chef_team_ids[i];
        int paused = inv->paused_team_ids[i];
        float x = startX + col * dx;
        float y = startY - row * dy;

        if (team == 3 && !sandwich_initialized[i]) {
            sandwich_chef_x[i] = x;
            sandwich_chef_y[i] = y;
            sandwich_initialized[i] = 1;
        }

        if (team == 3 && sandwich_moving[i]) {
            draw_chef_with_status(sandwich_chef_x[i], sandwich_chef_y[i], team, paused, blink_flag);
        } else {
            draw_chef_with_status(x, y, team, paused, blink_flag);
        }

        col++;
        if (col >= 3) { col = 0; row++; }
    }

    draw_ovens();

    float bakerY = startY - 4 * dy - 0.05f;
    for (int i = 0; i < MAX_BAKERS; ++i) {
        float bakerX = startX + i * dx;
        draw_baker(bakerX, bakerY, inv->baker_team_ids[i], inv->paused_bakerteam_ids[i], i);
    }

    for (int i = 0; i < MAX_BAKERS; ++i) {
        if (inv->baker_is_delivering[i]) {
            inv->baker_delivery_timer[i] -= 0.1f;
            if (inv->baker_delivery_timer[i] <= 0) {
                inv->baker_is_delivering[i] = 0;
            }
        }
    }

    for (int i = 0; i < MAX_CHEFS; i++) {
        if (inv->chef_team_ids[i] != 3 || !sandwich_moving[i]) continue;

        float tx = sandwich_start_x + (i % 4) * sandwich_x_gap;
        float ty = sandwich_y;

        if (sandwich_chef_x[i] < tx) sandwich_chef_x[i] += 0.003f;
        if (sandwich_chef_x[i] > tx) sandwich_chef_x[i] -= 0.003f;
        if (sandwich_chef_y[i] < ty) sandwich_chef_y[i] += 0.003f;
        if (sandwich_chef_y[i] > ty) sandwich_chef_y[i] -= 0.003f;

        if (fabs(sandwich_chef_x[i] - tx) < 0.005f &&
            fabs(sandwich_chef_y[i] - ty) < 0.005f) {
            sandwich_moving[i] = 0;
            inv->sandwich_chef_is_delivering[i] = 0;
            sandwich_chef_x[i] = startX + (i % 3) * dx;
            sandwich_chef_y[i] = startY - (i / 3) * dy;
        }
    }
}

void init_visualizer_state() {
    if (!inv) return;

    float startX = 0.15f, startY = 0.75f;
    float dx = 0.17f, dy = 0.18f;

    for (int i = 0; i < MAX_CHEFS; i++) {
        sandwich_moving[i] = 0;
        sandwich_initialized[i] = 0;

        if (inv->chef_team_ids[i] == 3) {
            inv->sandwich_chef_is_delivering[i] = 0;
            sandwich_chef_x[i] = startX + (i % 3) * dx;
            sandwich_chef_y[i] = startY - (i / 3) * dy;
        }
    }
}

void draw_manager(float x, float y) {
    float head_radius = 0.03f;

    // === Head ===
    glColor3f(1.0f, 0.9f, 0.8f); 
    glBegin(GL_POLYGON);
    for (int i = 0; i < 360; i++) {
        float theta = i * M_PI / 180.0;
        glVertex2f(x + cos(theta) * head_radius, y + sin(theta) * head_radius);
    }
    glEnd();

    float eye_dx = 0.01f, eye_dy = 0.01f;
    draw_circle(x - eye_dx, y + eye_dy, 0.003f, 0, 0, 0);
    draw_circle(x + eye_dx, y + eye_dy, 0.003f, 0, 0, 0);

    glColor3f(0.1f, 0.1f, 0.1f);
    float rx = 0.012f, ry = 0.008f;
    glBegin(GL_LINE_LOOP);
        glVertex2f(x - eye_dx - rx, y + eye_dy - ry);
        glVertex2f(x - eye_dx + rx, y + eye_dy - ry);
        glVertex2f(x - eye_dx + rx, y + eye_dy + ry);
        glVertex2f(x - eye_dx - rx, y + eye_dy + ry);
    glEnd();
    glBegin(GL_LINE_LOOP); 
        glVertex2f(x + eye_dx - rx, y + eye_dy - ry);
        glVertex2f(x + eye_dx + rx, y + eye_dy - ry);
        glVertex2f(x + eye_dx + rx, y + eye_dy + ry);
        glVertex2f(x + eye_dx - rx, y + eye_dy + ry);
    glEnd();
    glBegin(GL_LINES); 
        glVertex2f(x - 0.005f, y + eye_dy);
        glVertex2f(x + 0.005f, y + eye_dy);
    glEnd();

    
    glBegin(GL_LINE_STRIP);
    for (float theta = -M_PI / 4; theta <= M_PI / 4; theta += 0.1f) {
        glVertex2f(x + 0.01f * cosf(theta), y - 0.015f + 0.005f * sinf(theta));
    }
    glEnd();

    glColor3f(0.0f, 0.0f, 0.0f);
    glBegin(GL_QUADS);
        glVertex2f(x - 0.025f, y + head_radius + 0.005f);
        glVertex2f(x + 0.025f, y + head_radius + 0.005f);
        glVertex2f(x + 0.02f,  y + head_radius + 0.03f);
        glVertex2f(x - 0.02f,  y + head_radius + 0.03f);
    glEnd();

    glColor3f(0.2f, 0.2f, 0.6f);
    glBegin(GL_LINES);
        glVertex2f(x, y - head_radius);
        glVertex2f(x, y - head_radius - 0.08f);
    glEnd();

    glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_TRIANGLES);
        glVertex2f(x, y - head_radius - 0.02f);
        glVertex2f(x - 0.01f, y - head_radius - 0.05f);
        glVertex2f(x + 0.01f, y - head_radius - 0.05f);
    glEnd();

    float arm_angle_local = sinf(glutGet(GLUT_ELAPSED_TIME) / 200.0f) * 0.4f;

    glColor3f(0.1f, 0.1f, 0.1f);
    glBegin(GL_LINES);
        glVertex2f(x + 0.015f, y - 0.03f);
        glVertex2f(x + 0.015f + 0.04f * cosf(arm_angle_local),
                   y - 0.03f + 0.04f * sinf(arm_angle_local));
    glEnd();

    glBegin(GL_LINES);
        glVertex2f(x - 0.015f, y - 0.03f);
        glVertex2f(x - 0.055f, y - 0.03f);
    glEnd();

    if (inv && (
        inv->swap_sweet_cake ||
        inv->swap_sweet_savory_pat ||
        inv->swap_paste_sandwich
    )) {
        float alpha = fabs(sinf(glutGet(GLUT_ELAPSED_TIME) / 300.0f)); // pulsating glow
        glColor3f(alpha, alpha, 0.0f);
        draw_circle(x, y + 0.09f, 0.01f, alpha, alpha, 0.0f);
    }

    glColor3f(0.0f, 0.0f, 0.0f);
    draw_text(x - 0.035f, y - 0.13f, "Dr.Hana", GLUT_BITMAP_HELVETICA_12);

        glColor3f(0.8f, 0.2f, 0.2f); 

       
        if (swap_message_timer == 0) {
            if (inv->swap_sweet_cake) {
                strcpy(current_swap_msg, "Backup in Progress Cake-Sweet ");
                swap_message_timer = SWAP_MSG_DURATION;
                inv->swap_sweet_cake = 0;
            } else if (inv->swap_sweet_savory_pat) {
                strcpy(current_swap_msg, "Backup in Progress Sweet/Savory Pat");
                swap_message_timer = SWAP_MSG_DURATION;
                inv->swap_sweet_savory_pat = 0;
            } else if (inv->swap_paste_sandwich) {
                strcpy(current_swap_msg, "Backup in Progress Paste-Sandwich");
                swap_message_timer = SWAP_MSG_DURATION;
                inv->swap_paste_sandwich = 0;
            }
        }
        if (swap_message_timer > 0) {
            glColor3f(0.8f, 0.2f, 0.2f);
            draw_text(x - 0.07f, y - 0.16f, current_swap_msg, GLUT_BITMAP_HELVETICA_10);
            swap_message_timer--;
        }
        

    int message_set = 0;

// Detect new pause for chefs
for (int i = 0; i < MAX_CHEFS && !message_set; i++) {
    if (inv->paused_team_ids[i] && !prev_paused_state[i]) {
        switch (inv->chef_team_original_ids[i]) {
            case PASTE_TEAM:
                strcpy(current_pause_msg, "Pausing Paste Chefs Team");
                break;
            case CAKE_TEAM:
                strcpy(current_pause_msg, "Pausing Cake Chefs Team");
                break;
            case SANDWICH_TEAM:
                strcpy(current_pause_msg, "Pausing Sandwich Chefs Team");
                break;
            case SWEET_TEAM:
                strcpy(current_pause_msg, "Pausing Sweet Chefs Team");
                break;
            case SWEET_PATISSERIE_TEAM:
                strcpy(current_pause_msg, "Pausing Sweet Pat Chefs Team");
                break;
            case SAVORY_PATISSERIE_TEAM:
                strcpy(current_pause_msg, "Pausing Savory Pat Chefs Team");
                break;
        }
        pause_message_timer = 60;
        message_set = 1;
    }
}

for (int i = 0; i < MAX_BAKERS && !message_set; i++) {
    if (inv->paused_bakerteam_ids[i] && !prev_paused_baker[i]) {
        strcpy(current_pause_msg, "Pausing Bread Bakers Team");
        pause_message_timer = 120;
        message_set = 1;
    }
}

for (int i = 0; i < MAX_CHEFS; i++)
    prev_paused_state[i] = inv->paused_team_ids[i];
for (int i = 0; i < MAX_BAKERS; i++){
    prev_paused_baker[i] = inv->paused_bakerteam_ids[i];
    if (pause_message_timer > 0) {
        glColor3f(0.2f, 0.2f, 0.8f); 
        draw_text(x - 0.07f, y - 0.19f, current_pause_msg, GLUT_BITMAP_HELVETICA_10);
        pause_message_timer--;
    }
}

}



static void display(void) {
    if(inv) sem_wait(&inv->mutex);

    update_seller_states();
    update_customer_states();
    
    update_suppliers(); 
    
    update_sandwich_movement();
    glClearColor(0.98f,0.95f,0.92f,1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0.1f,0.1f,0.1f);
    draw_text(-0.20f,0.85f,"The Bakery - Live Monitor", GLUT_BITMAP_HELVETICA_18);
    draw_zones_layout();
    
    draw_manager(-0.1f, 0.6f); 

    draw_inventory_grid();
    draw_ready_to_sell_panel();
    draw_sellers_panel();
    draw_suppliers();

    draw_business_metrics();
    draw_customers();
    draw_termination_reason();
    draw_chefs_grid();  

    if(inv) sem_post(&inv->mutex);

    arm_angle += 0.1f;
if (arm_angle > 2 * M_PI) arm_angle -= 2 * M_PI;

    glutSwapBuffers();

}
int main(int argc, char **argv) {
    srand(time(NULL));
    attach_shared_memory();
    connect_message_queue();

    int sup_count = inv->num_supply_chain;
    if (sup_count<1) sup_count=2;
    if (sup_count>MAX_SUPPLIERS) sup_count=MAX_SUPPLIERS;

float span  = SUP_RIGHT_X - SUP_LEFT_X;
float base_gap = sup_count > 1 ? span / (sup_count - 1) : 0.0f;
float shrink = 0.4f;
float gap = base_gap * shrink;

for (int i = 0; i < sup_count; i++) {
    supplier_pos[i][0] = SUP_LEFT_X + i * gap;
    supplier_pos[i][1] = SUP_BASE_Y;  
    supplier_state[i] = 0;
    supplier_anim[i] = 0.0f;
    supplier_box_idx[i] = i % NUM_ITEMS;
    get_basket_pos(supplier_box_idx[i], &supplier_target[i][0], &supplier_target[i][1]);
}

    init_visualizer_state();  

    prev_salami_white = -1;
    prev_salami_brown = -1;
    prev_cheese_white = -1;
    prev_cheese_brown = -1;
    prev_both_white = -1;
    prev_both_brown = -1;


    for (int i = 0; i < MAX_CUSTOMERS; i++) {
        customer_positions[i][0] = -0.7f + 0.1f * i;
        customer_positions[i][1] = -0.5f;
        customer_states[i] = 0; 
        customer_animations[i] = 0;
        strcpy(customer_items[i], "Waiting...");
    }

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(1200,700);
    glutCreateWindow("Bakery Display");

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1,1,-1,1);

    glutDisplayFunc(display);
    glutTimerFunc(0, timer_cb, 0);
    glutMainLoop();
    return 0;
}