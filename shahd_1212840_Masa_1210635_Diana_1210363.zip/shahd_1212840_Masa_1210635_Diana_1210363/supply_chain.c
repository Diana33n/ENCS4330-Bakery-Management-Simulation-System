#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include "pantry.h"
#include "config_parser.h"
#include <signal.h>
#define LAVENDER "\x1B[38;5;183m"

#define RESET "\x1B[0m"
#define NUM_ITEMS 9
#define CHECK_INTERVAL 5
#define TOTAL_RUNTIME 500

volatile sig_atomic_t stop = 0;

enum Items { WHEAT, YEAST, BUTTER, MILK, SUGAR, SALT, SWEET_ITEMS, CHEESE, SALAMI };

void handle_sigterm(int sig) {
    printf("[Supply Chain] Received SIGTERM. Shutting down...\n");
    fflush(stdout);
    stop = 1;
}


void print_inventory(Inventory *inv) {
    printf("=== CURRENT INVENTORY STATUS ===\n");
    printf(LAVENDER"Wheat: %d\n"RESET, inv->wheat);
    printf(LAVENDER"Yeast: %d\n"RESET, inv->yeast);
    printf(LAVENDER"Butter: %d\n"RESET, inv->butter);
    printf(LAVENDER"Milk: %d\n"RESET, inv->milk);
    printf(LAVENDER"Sugar: %d\n"RESET, inv->sugar);
    printf(LAVENDER"Salt: %d\n"RESET, inv->salt);
    printf(LAVENDER"Sweet Items: %d\n"RESET, inv->sweet_items);
    printf(LAVENDER"Cheese: %d\n"RESET, inv->cheese);
    printf(LAVENDER"Salami: %d\n"RESET, inv->salami);
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <config_file>\n", argv[0]);
        return 1;
    }

    Inventory *inv = init_pantry(0);
    if (inv == NULL) {
        fprintf(stderr, "[Supply Chain] inv is NULL!\n");
        exit(1);
    }
    
    Config config = parse_config(argv[1]);

    if (config.wheat == 0 && config.yeast == 0) {
        printf("[DEBUG] Config values are all zero! Check config file path or contents.\n");
    }

    signal(SIGTERM, handle_sigterm);

    int initial_stock[NUM_ITEMS] = {
        config.wheat, config.yeast, config.butter, config.milk,
        config.sugar, config.salt, config.sweet_items, config.cheese, config.salami
    };

    const char* item_names[] = {
        "Wheat", "Yeast", "Butter", "Milk",
        "Sugar", "Salt", "Sweet Items", "Cheese", "Salami"
    };

    srand(time(NULL) ^ getpid());
    time_t start_time = time(NULL);

    while (!stop) {
        sleep(CHECK_INTERVAL);

        for (int i = 0; i < NUM_ITEMS; i++) {
            // 🔐 Lock
            switch (i) {
                case WHEAT: case BUTTER: case MILK: case SUGAR: case SWEET_ITEMS:
                    printf("[DEBUG] Waiting on sem_base_ingredients for %s\n", item_names[i]);
                    fflush(stdout);
                    sem_wait(&inv->sem_base_ingredients);
                    printf("[DEBUG] Acquired sem_base_ingredients for %s\n", item_names[i]);
                    break;
                case CHEESE: case SALAMI:
                    printf("[DEBUG] Waiting on sem_cheese_salami for %s\n", item_names[i]);
                    fflush(stdout);
                    sem_wait(&inv->sem_cheese_salami);
                    printf("[DEBUG] Acquired sem_cheese_salami for %s\n", item_names[i]);
                    break;
                case SALT:
                    printf("[DEBUG] Waiting on sem_salt\n");
                    fflush(stdout);
                    sem_wait(&inv->sem_salt);
                    printf("[DEBUG] Acquired sem_salt\n");
                    break;
                case YEAST:
                    printf("[DEBUG] Waiting on sem_paste\n");
                    fflush(stdout);
                    sem_wait(&inv->sem_paste);
                    printf("[DEBUG] Acquired sem_paste\n");
                    break;
            }

            int *current_stock = NULL;
            switch (i) {
                case WHEAT: current_stock = &inv->wheat; break;
                case YEAST: current_stock = &inv->yeast; break;
                case BUTTER: current_stock = &inv->butter; break;
                case MILK: current_stock = &inv->milk; break;
                case SUGAR: current_stock = &inv->sugar; break;
                case SALT: current_stock = &inv->salt; break;
                case SWEET_ITEMS: current_stock = &inv->sweet_items; break;
                case CHEESE: current_stock = &inv->cheese; break;
                case SALAMI: current_stock = &inv->salami; break;
            }

            int quarter = (initial_stock[i] > 3) ? initial_stock[i] / 4 : 1;

            if (*current_stock <= quarter) {
                printf(LAVENDER"[WARNING] %s stock low (%d units)!\n"RESET, item_names[i], *current_stock);
                int restock_amount = quarter + 1;
                sleep(2);
                *current_stock += restock_amount;
                printf(LAVENDER"[Supply Chain] Restocked %d units of %s. New stock: %d\n"RESET,
                       restock_amount, item_names[i], *current_stock);
            }

            // 🔓 Unlock
            switch (i) {
                case WHEAT: case BUTTER: case MILK: case SUGAR: case SWEET_ITEMS:
                    printf("[DEBUG] Releasing sem_base_ingredients for %s\n", item_names[i]);
                    sem_post(&inv->sem_base_ingredients);
                    break;
                case CHEESE: case SALAMI:
                    printf("[DEBUG] Releasing sem_cheese_salami for %s\n", item_names[i]);
                    sem_post(&inv->sem_cheese_salami);
                    break;
                case SALT:
                    printf("[DEBUG] Releasing sem_salt\n");
                    sem_post(&inv->sem_salt);
                    break;
                case YEAST:
                    printf("[DEBUG] Releasing sem_paste\n");
                    sem_post(&inv->sem_paste);
                    break;
            }

            fflush(stdout);
        }

        printf("\n[DEBUG] Completed restock cycle. Inventory now:\n");
        print_inventory(inv);
        fflush(stdout);

        time_t now = time(NULL);
        if ((now - start_time) >= TOTAL_RUNTIME) {
            printf("[Supply Chain] Reached total runtime, stopping.\n");
            break;
        }
    }

    return 0;
}
